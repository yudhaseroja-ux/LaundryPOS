/**
 * Google Apps Script (Code.gs) template for UMKM LaundryPOS.
 * UMKM owner can copy this script and paste it into Google Apps Script connected to Google Sheet.
 */

export const GAS_SCRIPT_CODE = `/**
 * =========================================================================
 * LAUNDRYPOS - GOOGLE APPS SCRIPT API ENGINE (Code.gs)
 * Backend & Database bridge for Google Sheets
 * Sinkronisasi Layanan & Tarif, Pelanggan, User Kasir, Transaksi & Pengeluaran
 * =========================================================================
 * 
 * CARA DEPLOY:
 * 1. Buka Google Spreadsheet baru di Google Drive Anda (sheet.new).
 * 2. Klik menu 'Ekstensi' (Extensions) -> 'Apps Script'.
 * 3. Hapus kode default di Code.gs, lalu Tempel (Paste) seluruh kode ini.
 * 4. Klik 'Deploy' (Terapkan) -> 'New Deployment' (Penerapan Baru).
 * 5. Pilih type: 'Web App'.
 * 6. Set "Execute as": "Me (email Anda)".
 * 7. Set "Who has access": "Anyone" (Siapa saja).
 * 8. Klik 'Deploy', izinkan otorisasi, lalu salin URL Web App yang didapat ke menu Pengaturan di LaundryPOS.
 */

function doGet(e) {
  return handleRequest(e, 'GET');
}

function doPost(e) {
  return handleRequest(e, 'POST');
}

function handleRequest(e, method) {
  var output = { success: false, data: null, error: null };
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    initSheetsIfNotExist(ss);
    
    var params = e && e.parameter ? e.parameter : {};
    var action = params.action;
    var postData = null;
    
    if (method === 'POST' && e && e.postData && e.postData.contents) {
      try {
        postData = JSON.parse(e.postData.contents);
        if (postData.action && !action) {
          action = postData.action;
        }
      } catch (err) {
        // Fallback jika dikirim via URL parameter
      }
    }
    
    if (!action) {
      action = 'ping';
    }

    switch (action) {
      case 'ping':
        output.success = true;
        output.data = { status: 'online', time: new Date().toISOString(), message: 'LaundryPOS GAS API siap & terhubung dengan Google Sheets!' };
        break;

      // --- AMBIL SEMUA DATA (PULL KE APLIKASI) ---
      case 'getAllData':
        output.success = true;
        output.data = {
          services: getSheetDataAsObjects(ss.getSheetByName('services')),
          customers: getSheetDataAsObjects(ss.getSheetByName('customers')),
          users: getSheetDataAsObjects(ss.getSheetByName('users')),
          transactions: getSheetDataAsObjects(ss.getSheetByName('transactions')),
          transaction_items: getSheetDataAsObjects(ss.getSheetByName('transaction_items')),
          payments: getSheetDataAsObjects(ss.getSheetByName('payments')),
          laundry_status: getSheetDataAsObjects(ss.getSheetByName('laundry_status')),
          expenses: getSheetDataAsObjects(ss.getSheetByName('expenses')),
          settings: getSheetDataAsObjects(ss.getSheetByName('settings'))
        };
        break;

      // --- SINKRONISASI BATCH SEMUA MASTER DATA (PUSH DARI APLIKASI) ---
      case 'syncAllMasterData':
      case 'syncAllData':
        if (postData) {
          if (postData.services && postData.services.length) {
            overwriteSheetWithData(ss.getSheetByName('services'), postData.services, [
              'id', 'code', 'name', 'unit', 'price', 'category', 'durationHours', 'status', 'description'
            ]);
          }
          if (postData.customers && postData.customers.length) {
            overwriteSheetWithData(ss.getSheetByName('customers'), postData.customers, [
              'id', 'code', 'name', 'phone', 'address', 'gender', 'notes', 'total_transactions', 'total_spent', 'piutang_amount', 'created_at'
            ]);
          }
          if (postData.users && postData.users.length) {
            overwriteSheetWithData(ss.getSheetByName('users'), postData.users, [
              'id', 'name', 'username', 'password', 'role', 'status'
            ]);
          }
          if (postData.transactions && postData.transactions.length) {
            overwriteSheetWithData(ss.getSheetByName('transactions'), postData.transactions, [
              'id', 'invoice', 'customer_id', 'customer_name', 'customer_phone', 'customer_address', 'date', 'estimated_completion_date', 'subtotal', 'discount', 'tax', 'total', 'paid_amount', 'debt_amount', 'change_amount', 'payment_method', 'status', 'payment_status', 'perfume', 'rack_location', 'notes', 'created_by', 'cashier_name'
            ]);
          }
          if (postData.expenses && postData.expenses.length) {
            overwriteSheetWithData(ss.getSheetByName('expenses'), postData.expenses, [
              'id', 'date', 'category', 'description', 'amount', 'payment_method', 'created_by'
            ]);
          }
        }
        output.success = true;
        output.data = { message: 'Semua data master berhasil disinkronkan ke Google Spreadsheet!' };
        break;

      // --- SINKRONISASI LAYANAN & TARIF ---
      case 'syncAllServices':
        if (postData && postData.services) {
          overwriteSheetWithData(ss.getSheetByName('services'), postData.services, [
            'id', 'code', 'name', 'unit', 'price', 'category', 'durationHours', 'status', 'description'
          ]);
          output.success = true;
          output.data = { count: postData.services.length };
        }
        break;

      case 'saveService':
        if (!postData || !postData.service) throw new Error('Data layanan tidak valid');
        upsertRowById(ss.getSheetByName('services'), postData.service, [
          'id', 'code', 'name', 'unit', 'price', 'category', 'durationHours', 'status', 'description'
        ]);
        output.success = true;
        break;

      // --- SINKRONISASI PELANGGAN ---
      case 'syncAllCustomers':
        if (postData && postData.customers) {
          overwriteSheetWithData(ss.getSheetByName('customers'), postData.customers, [
            'id', 'code', 'name', 'phone', 'address', 'gender', 'notes', 'total_transactions', 'total_spent', 'piutang_amount', 'created_at'
          ]);
          output.success = true;
          output.data = { count: postData.customers.length };
        }
        break;

      case 'createCustomer':
      case 'saveCustomer':
        if (!postData || !postData.customer) throw new Error('Data pelanggan tidak valid');
        upsertRowById(ss.getSheetByName('customers'), postData.customer, [
          'id', 'code', 'name', 'phone', 'address', 'gender', 'notes', 'total_transactions', 'total_spent', 'piutang_amount', 'created_at'
        ]);
        output.success = true;
        break;

      // --- SINKRONISASI USER / KARYAWAN ---
      case 'syncAllUsers':
        if (postData && postData.users) {
          overwriteSheetWithData(ss.getSheetByName('users'), postData.users, [
            'id', 'name', 'username', 'password', 'role', 'status'
          ]);
          output.success = true;
          output.data = { count: postData.users.length };
        }
        break;

      case 'saveUser':
        if (!postData || !postData.user) throw new Error('Data user tidak valid');
        upsertRowById(ss.getSheetByName('users'), postData.user, [
          'id', 'name', 'username', 'password', 'role', 'status'
        ]);
        output.success = true;
        break;

      // --- TRANSAKSI BARU ---
      case 'createTransaction':
        if (!postData || !postData.transaction) {
          throw new Error('Data transaksi tidak ditemukan');
        }
        var trx = postData.transaction;
        var trxSheet = ss.getSheetByName('transactions');
        var itemSheet = ss.getSheetByName('transaction_items');
        var paySheet = ss.getSheetByName('payments');
        var statusSheet = ss.getSheetByName('laundry_status');

        trxSheet.appendRow([
          trx.id,
          trx.invoice,
          trx.customer_id,
          trx.customer_name || '',
          trx.customer_phone || '',
          trx.customer_address || '',
          trx.date,
          trx.estimated_completion_date || '',
          trx.subtotal,
          trx.discount,
          trx.tax || 0,
          trx.total,
          trx.paid_amount,
          trx.debt_amount,
          trx.change_amount || 0,
          trx.payment_method,
          trx.status,
          trx.payment_status,
          trx.perfume || trx.perfume_choice || '',
          trx.rack_location || '',
          trx.notes || '',
          trx.created_by || '',
          trx.cashier_name || ''
        ]);

        if (trx.items && trx.items.length) {
          trx.items.forEach(function(item) {
            itemSheet.appendRow([
              item.id || Utilities.getUuid(),
              trx.id,
              item.service_id,
              item.service_code || '',
              item.service_name,
              item.qty,
              item.unit,
              item.price,
              item.subtotal,
              item.notes || ''
            ]);
          });
        }

        if (trx.payment_methods && trx.payment_methods.length) {
          trx.payment_methods.forEach(function(p) {
            paySheet.appendRow([
              Utilities.getUuid(),
              trx.id,
              p.method,
              p.amount,
              new Date().toISOString()
            ]);
          });
        }

        statusSheet.appendRow([
          Utilities.getUuid(),
          trx.id,
          trx.status || 'antri',
          new Date().toISOString(),
          trx.cashier_name || trx.created_by || 'Kasir',
          'Penerimaan transaksi baru'
        ]);

        output.success = true;
        output.data = { invoice: trx.invoice, id: trx.id };
        break;

      // --- UPDATE STATUS CUCIAN ---
      case 'updateLaundryStatus':
        if (!postData) throw new Error('Data status tidak valid');
        var lSheet = ss.getSheetByName('laundry_status');
        var tSheet = ss.getSheetByName('transactions');
        lSheet.appendRow([
          Utilities.getUuid(),
          postData.transaction_id,
          postData.status,
          new Date().toISOString(),
          postData.user_name || 'Operator',
          postData.notes || ''
        ]);
        
        var tData = tSheet.getDataRange().getValues();
        for (var i = 1; i < tData.length; i++) {
          if (tData[i][0] == postData.transaction_id || tData[i][1] == postData.invoice) {
            tSheet.getRange(i + 1, 17).setValue(postData.status);
            if (postData.rack_location) {
              tSheet.getRange(i + 1, 20).setValue(postData.rack_location);
            }
            break;
          }
        }
        output.success = true;
        break;

      // --- CATAT PENGELUARAN ---
      case 'createExpense':
        if (!postData || !postData.expense) throw new Error('Data pengeluaran tidak valid');
        var exp = postData.expense;
        var expSheet = ss.getSheetByName('expenses');
        expSheet.appendRow([
          exp.id || Utilities.getUuid(),
          exp.date || new Date().toISOString(),
          exp.category,
          exp.description,
          exp.amount,
          exp.payment_method,
          exp.created_by || ''
        ]);
        output.success = true;
        break;

      // --- INISIALISASI STRUKTUR SPREADSHEET ---
      case 'initDatabase':
        initSheetsIfNotExist(ss);
        output.success = true;
        output.data = { message: 'Semua sheet database berhasil disiapkan di Spreadsheet!' };
        break;

      default:
        output.error = 'Action ' + action + ' tidak dikenali.';
    }
  } catch (error) {
    output.success = false;
    output.error = error.toString();
  }

  return ContentService.createTextOutput(JSON.stringify(output))
    .setMimeType(ContentService.MimeType.JSON);
}

// Inisialisasi Sheet & Header jika belum ada
function initSheetsIfNotExist(ss) {
  var sheetSchemas = {
    'users': ['id', 'name', 'username', 'password', 'role', 'status'],
    'customers': ['id', 'code', 'name', 'phone', 'address', 'gender', 'notes', 'total_transactions', 'total_spent', 'piutang_amount', 'created_at'],
    'services': ['id', 'code', 'name', 'unit', 'price', 'category', 'durationHours', 'status', 'description'],
    'transactions': ['id', 'invoice', 'customer_id', 'customer_name', 'customer_phone', 'customer_address', 'date', 'estimated_completion_date', 'subtotal', 'discount', 'tax', 'total', 'paid_amount', 'debt_amount', 'change_amount', 'payment_method', 'status', 'payment_status', 'perfume', 'rack_location', 'notes', 'created_by', 'cashier_name'],
    'transaction_items': ['id', 'transaction_id', 'service_id', 'service_code', 'service_name', 'qty', 'unit', 'price', 'subtotal', 'notes'],
    'payments': ['id', 'transaction_id', 'method', 'amount', 'date'],
    'laundry_status': ['id', 'transaction_id', 'status', 'timestamp', 'user_name', 'notes'],
    'expenses': ['id', 'date', 'category', 'description', 'amount', 'payment_method', 'created_by'],
    'settings': ['key', 'value']
  };

  for (var sheetName in sheetSchemas) {
    var sheet = ss.getSheetByName(sheetName);
    var headers = sheetSchemas[sheetName];
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      sheet.appendRow(headers);
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#0284C7')
        .setFontColor('#FFFFFF');
    }
  }
}

// Utility: Timpa Sheet dengan Array Object
function overwriteSheetWithData(sheet, dataArray, keys) {
  if (!sheet) return;
  var lastRow = sheet.getLastRow();
  if (lastRow > 1) {
    sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).clearContent();
  }
  if (!dataArray || !dataArray.length) return;
  
  var rows = dataArray.map(function(item) {
    return keys.map(function(k) {
      return item[k] !== undefined && item[k] !== null ? item[k] : '';
    });
  });
  sheet.getRange(2, 1, rows.length, keys.length).setValues(rows);
}

// Utility: Upsert satu baris berdasarkan field ID (kolom 1)
function upsertRowById(sheet, obj, keys) {
  if (!sheet || !obj) return;
  var id = obj.id;
  var data = sheet.getDataRange().getValues();
  var rowIndex = -1;
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] == id) {
      rowIndex = i + 1;
      break;
    }
  }
  var rowValues = keys.map(function(k) {
    return obj[k] !== undefined && obj[k] !== null ? obj[k] : '';
  });

  if (rowIndex > 0) {
    sheet.getRange(rowIndex, 1, 1, keys.length).setValues([rowValues]);
  } else {
    sheet.appendRow(rowValues);
  }
}

// Utility: Baca Sheet sebagai Array of Objects
function getSheetDataAsObjects(sheet) {
  if (!sheet) return [];
  var data = sheet.getDataRange().getValues();
  if (data.length <= 1) return [];
  var headers = data[0];
  var rows = [];
  for (var r = 1; r < data.length; r++) {
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      obj[headers[c]] = data[r][c];
    }
    rows.push(obj);
  }
  return rows;
}
`;
