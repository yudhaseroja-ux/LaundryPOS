import {
  INITIAL_CUSTOMERS,
  INITIAL_EXPENSES,
  INITIAL_SERVICES,
  INITIAL_STORE_SETTINGS,
  INITIAL_TRANSACTIONS,
  INITIAL_USERS,
} from '../data/seedData';
import {
  Customer,
  Expense,
  LaundryStatus,
  PaymentMethod,
  Service,
  SplitPaymentRecord,
  StoreSettings,
  Transaction,
  User,
} from '../types';

const STORAGE_KEYS = {
  USERS: 'laundrypos_users',
  CUSTOMERS: 'laundrypos_customers',
  SERVICES: 'laundrypos_services',
  TRANSACTIONS: 'laundrypos_transactions',
  EXPENSES: 'laundrypos_expenses',
  SETTINGS: 'laundrypos_settings',
  ACTIVE_USER: 'laundrypos_active_user',
};

export class AppStorage {
  // --- USERS ---
  static getUsers(): User[] {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    try {
      const parsed: User[] = JSON.parse(raw);
      if (!parsed.some(u => u.username.toLowerCase() === 'admin')) {
        const adminUser = INITIAL_USERS[0];
        const merged = [adminUser, ...parsed];
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(merged));
        return merged;
      }
      return parsed;
    } catch {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
  }

  static getActiveUser(): User | null {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
    if (!raw) {
      return null;
    }
    return JSON.parse(raw);
  }

  static setActiveUser(user: User | null): void {
    if (!user) {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
    } else {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(user));
    }
  }

  static login(username: string, password?: string): User | null {
    const users = this.getUsers();
    // Default admin / admin or existing users
    const matched = users.find(u => {
      if (u.username.toLowerCase() === username.trim().toLowerCase()) {
        if (!u.password) return password === 'admin' || password === 'password';
        return u.password === password;
      }
      return false;
    });

    if (matched) {
      this.setActiveUser(matched);
      return matched;
    }
    // If username is admin and password is admin, fallback create and return
    if (username.trim().toLowerCase() === 'admin' && password === 'admin') {
      const adminUser: User = {
        id: 'usr-admin',
        name: 'Administrator (Owner)',
        username: 'admin',
        password: 'admin',
        role: 'owner',
        status: 'active',
      };
      this.setActiveUser(adminUser);
      return adminUser;
    }

    return null;
  }

  static saveUser(user: User): User[] {
    const list = this.getUsers();
    const existingIdx = list.findIndex(u => u.id === user.id);
    if (existingIdx >= 0) {
      list[existingIdx] = user;
    } else {
      list.push({
        ...user,
        id: user.id || `usr-${Date.now().toString().slice(-4)}`,
        status: user.status || 'active',
      });
    }
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(list));
    this.pushToGas('syncAllUsers', { users: list });
    return list;
  }

  static deleteUser(id: string): User[] {
    const list = this.getUsers().filter(u => u.id !== id);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(list));
    this.pushToGas('syncAllUsers', { users: list });
    return list;
  }

  static logout(): void {
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
  }

  // --- SETTINGS ---
  static getSettings(): StoreSettings {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_STORE_SETTINGS));
      return INITIAL_STORE_SETTINGS;
    }
    try {
      const parsed: StoreSettings = JSON.parse(raw);
      let updated = false;
      if (!parsed.gas_sync_mode || parsed.gas_sync_mode === 'local') {
        parsed.gas_sync_mode = 'live';
        updated = true;
      }
      if (!parsed.gas_api_url) {
        parsed.gas_api_url = INITIAL_STORE_SETTINGS.gas_api_url;
        updated = true;
      }
      if (updated) {
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(parsed));
      }
      return parsed;
    } catch {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_STORE_SETTINGS));
      return INITIAL_STORE_SETTINGS;
    }
  }

  static saveSettings(settings: StoreSettings): void {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }

  // --- CUSTOMERS ---
  static getCustomers(): Customer[] {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
      return INITIAL_CUSTOMERS;
    }
    return JSON.parse(raw);
  }

  static saveCustomer(customer: Customer): Customer[] {
    const list = this.getCustomers();
    const existingIdx = list.findIndex(c => c.id === customer.id);
    if (existingIdx >= 0) {
      list[existingIdx] = { ...list[existingIdx], ...customer, updated_at: new Date().toISOString() };
    } else {
      list.unshift({
        ...customer,
        id: customer.id || `CUS-${Date.now().toString().slice(-4)}`,
        code: customer.code || `CUS-${(list.length + 1).toString().padStart(3, '0')}`,
        created_at: new Date().toISOString(),
        total_transactions: customer.total_transactions || 0,
        total_spent: customer.total_spent || 0,
        piutang_amount: customer.piutang_amount || 0,
      });
    }
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(list));

    // Async push to GAS if live mode
    this.pushToGas('syncAllCustomers', { customers: list });
    return list;
  }

  static deleteCustomer(id: string): Customer[] {
    const list = this.getCustomers().filter(c => c.id !== id);
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(list));
    this.pushToGas('syncAllCustomers', { customers: list });
    return list;
  }

  // --- SERVICES ---
  static getServices(): Service[] {
    const raw = localStorage.getItem(STORAGE_KEYS.SERVICES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(INITIAL_SERVICES));
      return INITIAL_SERVICES;
    }
    return JSON.parse(raw);
  }

  static saveService(service: Service): Service[] {
    const list = this.getServices();
    const existingIdx = list.findIndex(s => s.id === service.id);
    if (existingIdx >= 0) {
      list[existingIdx] = service;
    } else {
      list.push({
        ...service,
        id: service.id || `SRV-${(list.length + 1).toString().padStart(3, '0')}`,
        code: service.code || `L${(list.length + 1).toString().padStart(3, '0')}`,
      });
    }
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(list));
    this.pushToGas('syncAllServices', { services: list });
    return list;
  }

  static deleteService(id: string): Service[] {
    const list = this.getServices().filter(s => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(list));
    this.pushToGas('syncAllServices', { services: list });
    return list;
  }

  // --- TRANSACTIONS ---
  static getTransactions(): Transaction[] {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(INITIAL_TRANSACTIONS));
      return INITIAL_TRANSACTIONS;
    }
    return JSON.parse(raw);
  }

  static saveTransaction(trx: Transaction): { transactions: Transaction[]; customers: Customer[] } {
    const transactions = this.getTransactions();
    const customers = this.getCustomers();

    // Check if new or update
    const existingIdx = transactions.findIndex(t => t.id === trx.id);
    if (existingIdx >= 0) {
      transactions[existingIdx] = trx;
    } else {
      transactions.unshift(trx);

      // Update customer stats
      const customerIdx = customers.findIndex(c => c.id === trx.customer_id);
      if (customerIdx >= 0) {
        customers[customerIdx].total_transactions = (customers[customerIdx].total_transactions || 0) + 1;
        customers[customerIdx].total_spent = (customers[customerIdx].total_spent || 0) + trx.total;
        if (trx.debt_amount > 0) {
          customers[customerIdx].piutang_amount = (customers[customerIdx].piutang_amount || 0) + trx.debt_amount;
        }
        localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
      }
    }

    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));

    // Send to Google Apps Script backend if configured
    this.pushToGas('createTransaction', { transaction: trx });

    return { transactions, customers };
  }

  static updateLaundryStatus(
    transactionId: string,
    newStatus: LaundryStatus,
    userName: string,
    notes?: string
  ): Transaction[] {
    const transactions = this.getTransactions();
    const trx = transactions.find(t => t.id === transactionId);
    if (!trx) return transactions;

    trx.status = newStatus;
    if (!trx.status_history) {
      trx.status_history = [];
    }

    trx.status_history.push({
      id: `sh-${Date.now()}`,
      status: newStatus,
      timestamp: new Date().toISOString(),
      user_name: userName,
      notes: notes || undefined,
    });

    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));

    this.pushToGas('updateLaundryStatus', {
      transaction_id: transactionId,
      invoice: trx.invoice,
      status: newStatus,
      user_name: userName,
    });

    return transactions;
  }

  static settleDebt(
    transactionId: string,
    amount: number,
    paymentMethod: PaymentMethod
  ): { transactions: Transaction[]; customers: Customer[] } {
    const transactions = this.getTransactions();
    const customers = this.getCustomers();
    const trx = transactions.find(t => t.id === transactionId);
    if (!trx) return { transactions, customers };

    const actualAmount = Math.min(amount, trx.debt_amount);
    trx.paid_amount += actualAmount;
    trx.debt_amount = Math.max(0, trx.debt_amount - actualAmount);

    if (trx.debt_amount <= 0) {
      trx.payment_status = 'lunas';
    } else {
      trx.payment_status = 'sebagian';
    }

    if (!trx.payment_methods) trx.payment_methods = [];
    trx.payment_methods.push({
      method: paymentMethod,
      amount: actualAmount,
      reference: `Pelunasan piutang ${new Date().toLocaleDateString('id-ID')}`,
    });

    // Update customer debt
    const customer = customers.find(c => c.id === trx.customer_id);
    if (customer) {
      customer.piutang_amount = Math.max(0, (customer.piutang_amount || 0) - actualAmount);
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
    }

    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));

    return { transactions, customers };
  }

  // --- EXPENSES ---
  static getExpenses(): Expense[] {
    const raw = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(INITIAL_EXPENSES));
      return INITIAL_EXPENSES;
    }
    return JSON.parse(raw);
  }

  static saveExpense(expense: Expense): Expense[] {
    const list = this.getExpenses();
    const item = {
      ...expense,
      id: expense.id || `EXP-${Date.now()}`,
      date: expense.date || new Date().toISOString(),
    };
    list.unshift(item);
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(list));

    this.pushToGas('createExpense', { expense: item });
    return list;
  }

  static deleteExpense(id: string): Expense[] {
    const list = this.getExpenses().filter(e => e.id !== id);
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(list));
    return list;
  }

  // --- GOOGLE APPS SCRIPT LIVE BRIDGE ---
  private static async pushToGas(action: string, payload: Record<string, unknown>): Promise<void> {
    const settings = this.getSettings();
    if (settings.gas_sync_mode !== 'live' || !settings.gas_api_url) {
      return;
    }

    try {
      await fetch(settings.gas_api_url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action, ...payload }),
        mode: 'no-cors', // Standard Google Apps Script Web App endpoint handling
      });
    } catch (e) {
      console.warn('Google Apps Script background sync failed:', e);
    }
  }

  static async testGasConnection(url: string): Promise<{ success: boolean; message: string }> {
    try {
      if (!url.startsWith('http')) {
        return { success: false, message: 'URL Google Apps Script harus diawali dengan https://script.google.com/macros/s/...' };
      }
      const testUrl = `${url}${url.includes('?') ? '&' : '?'}action=ping`;
      const response = await fetch(testUrl, { method: 'GET' });
      const data = await response.json();
      if (data && data.success) {
        return { success: true, message: 'Terhubung ke Google Spreadsheet! ' + (data.data?.message || '') };
      }
      return { success: false, message: data.error || 'Respon dari Apps Script tidak sesuai format.' };
    } catch (err: unknown) {
      return {
        success: false,
        message: 'Gagal terhubung: Pastikan Web App di-deploy dengan akses "Anyone" (Siapa saja) dan cek koneksi internet Anda.',
      };
    }
  }

  static async pushAllToGas(): Promise<{ success: boolean; message: string }> {
    const settings = this.getSettings();
    if (!settings.gas_api_url) {
      return { success: false, message: 'URL Google Apps Script belum diisi di Pengaturan.' };
    }
    try {
      const payload = {
        action: 'syncAllMasterData',
        services: this.getServices(),
        customers: this.getCustomers(),
        users: this.getUsers(),
        transactions: this.getTransactions(),
        expenses: this.getExpenses(),
      };
      await fetch(settings.gas_api_url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(payload),
        mode: 'no-cors',
      });
      return {
        success: true,
        message: 'Semua Layanan & Tarif, Pelanggan, User Kasir, dan Transaksi berhasil dikirim ke Google Spreadsheet!',
      };
    } catch (err: unknown) {
      return { success: false, message: 'Gagal mengirim data: ' + String(err) };
    }
  }

  static async pullAllFromGas(): Promise<{
    success: boolean;
    message: string;
    data?: {
      services: Service[];
      customers: Customer[];
      users: User[];
      transactions: Transaction[];
      expenses: Expense[];
    };
  }> {
    const settings = this.getSettings();
    if (!settings.gas_api_url) {
      return { success: false, message: 'URL Google Apps Script belum diisi di Pengaturan.' };
    }
    try {
      const url = `${settings.gas_api_url}${settings.gas_api_url.includes('?') ? '&' : '?'}action=getAllData`;
      const res = await fetch(url, { method: 'GET' });
      const json = await res.json();
      if (!json || !json.success || !json.data) {
        return { success: false, message: json?.error || 'Gagal membaca data dari Google Spreadsheet.' };
      }

      const d = json.data;
      let updatedServices = this.getServices();
      let updatedCustomers = this.getCustomers();
      let updatedUsers = this.getUsers();
      let updatedTransactions = this.getTransactions();
      let updatedExpenses = this.getExpenses();

      if (Array.isArray(d.services) && d.services.length > 0) {
        updatedServices = d.services.map((s: Record<string, unknown>, idx: number) => ({
          id: String(s.id || `SRV-${idx + 1}`),
          code: String(s.code || `L${idx + 1}`),
          name: String(s.name || ''),
          unit: (s.unit || 'Kg') as any,
          price: Number(s.price || 0),
          category: (s.category || 'kiloan') as any,
          durationHours: Number(s.durationHours || 24),
          status: (s.status || 'active') as any,
          description: String(s.description || ''),
        }));
        localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(updatedServices));
      }

      if (Array.isArray(d.customers) && d.customers.length > 0) {
        updatedCustomers = d.customers.map((c: Record<string, unknown>, idx: number) => ({
          id: String(c.id || `CUS-${idx + 1}`),
          code: String(c.code || `CUS-${idx + 1}`),
          name: String(c.name || ''),
          phone: String(c.phone || ''),
          address: String(c.address || ''),
          gender: (c.gender || 'L') as any,
          notes: String(c.notes || ''),
          created_at: String(c.created_at || new Date().toISOString()),
          total_transactions: Number(c.total_transactions || 0),
          total_spent: Number(c.total_spent || 0),
          piutang_amount: Number(c.piutang_amount || 0),
        }));
        localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(updatedCustomers));
      }

      if (Array.isArray(d.users) && d.users.length > 0) {
        updatedUsers = d.users.map((u: Record<string, unknown>, idx: number) => ({
          id: String(u.id || `usr-${idx + 1}`),
          name: String(u.name || ''),
          username: String(u.username || ''),
          password: String(u.password || 'password'),
          role: (u.role || 'kasir') as any,
          status: (u.status || 'active') as any,
        }));
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updatedUsers));
      }

      return {
        success: true,
        message: `Berhasil mengimpor: ${updatedServices.length} Layanan, ${updatedCustomers.length} Pelanggan, ${updatedUsers.length} User dari Google Spreadsheet!`,
        data: {
          services: updatedServices,
          customers: updatedCustomers,
          users: updatedUsers,
          transactions: updatedTransactions,
          expenses: updatedExpenses,
        },
      };
    } catch (err: unknown) {
      return {
        success: false,
        message: 'Gagal mengambil data dari Google Spreadsheet: ' + String(err),
      };
    }
  }

  // --- RESET & BACKUP ---
  static initFreshStart(): void {
    const isApplied = localStorage.getItem('laundrypos_clear_piutang_v1');
    if (!isApplied) {
      this.clearDebtTransactions();
      localStorage.setItem('laundrypos_clear_piutang_v1', 'true');
    }
  }

  static clearDebtTransactions(): { transactions: Transaction[]; customers: Customer[] } {
    // Remove all transactions that have outstanding debt
    const transactions = this.getTransactions().filter(t => (t.debt_amount || 0) <= 0);
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));

    // Zero out all customer debts
    const customers = this.getCustomers().map(c => ({
      ...c,
      piutang_amount: 0,
    }));
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));

    this.pushToGas('syncAllData', { transactions, customers });
    return { transactions, customers };
  }

  static deleteDebtTransaction(transactionId: string): { transactions: Transaction[]; customers: Customer[] } {
    const transactions = this.getTransactions().filter(t => t.id !== transactionId);
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));

    const customers = this.getCustomers().map(c => {
      const remainingDebt = transactions
        .filter(t => t.customer_id === c.id)
        .reduce((sum, t) => sum + (t.debt_amount || 0), 0);
      return {
        ...c,
        piutang_amount: remainingDebt,
      };
    });
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));

    this.pushToGas('syncAllData', { transactions, customers });
    return { transactions, customers };
  }

  static resetToDemo(): void {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(INITIAL_SERVICES));
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_STORE_SETTINGS));
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(INITIAL_USERS[0]));
  }

  static clearTransactionsAndDebts(): void {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify([]));
    // Reset debt, spent, and transaction count for customers
    const customers = this.getCustomers().map(c => ({
      ...c,
      total_spent: 0,
      total_transactions: 0,
      piutang_amount: 0,
      unpaid_debt: 0,
    }));
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }

  static factoryReset(): void {
    localStorage.clear();
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(INITIAL_SERVICES));
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_STORE_SETTINGS));
  }

  static exportBackupJson(): string {
    const backup = {
      version: '1.0',
      exported_at: new Date().toISOString(),
      store_settings: this.getSettings(),
      customers: this.getCustomers(),
      services: this.getServices(),
      transactions: this.getTransactions(),
      expenses: this.getExpenses(),
    };
    return JSON.stringify(backup, null, 2);
  }

  static importBackupJson(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.customers) localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(data.customers));
      if (data.services) localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(data.services));
      if (data.transactions) localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(data.transactions));
      if (data.expenses) localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(data.expenses));
      if (data.store_settings) localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.store_settings));
      return true;
    } catch {
      return false;
    }
  }
}
