import React, { useState } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Tag,
  CheckCircle2,
  XCircle,
  Clock,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Service, ServiceUnit } from '../types';
import { formatRupiah } from '../utils/currency';

interface Props {
  services: Service[];
  onSaveService: (service: Service) => void;
}

export const Services: React.FC<Props> = ({ services, onSaveService }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);

  const [formData, setFormData] = useState<Partial<Service>>({
    code: '',
    name: '',
    unit: 'Kg',
    price: 8000,
    status: 'active',
    durationHours: 24,
    category: 'kiloan',
    description: '',
  });

  const filteredServices = services.filter(
    s =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingService(null);
    setFormData({
      code: `L${(services.length + 1).toString().padStart(3, '0')}`,
      name: '',
      unit: 'Kg',
      price: 8000,
      status: 'active',
      durationHours: 24,
      category: 'kiloan',
      description: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (service: Service) => {
    setEditingService(service);
    setFormData(service);
    setIsModalOpen(true);
  };

  const handleToggleStatus = (service: Service) => {
    onSaveService({
      ...service,
      status: service.status === 'active' ? 'inactive' : 'active',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name?.trim()) return;

    onSaveService({
      id: editingService?.id || `SRV-${Date.now().toString().slice(-4)}`,
      code: formData.code?.trim() || `L${(services.length + 1).toString().padStart(3, '0')}`,
      name: formData.name.trim(),
      unit: (formData.unit as ServiceUnit) || 'Kg',
      price: Number(formData.price) || 0,
      status: (formData.status as 'active' | 'inactive') || 'active',
      durationHours: Number(formData.durationHours) || 24,
      category: formData.category as any,
      description: formData.description?.trim() || '',
    });

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900">Katalog Layanan & Tarif</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola jenis cucian kiloan, satuan, kilat express, dan harga per satuan.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari nama atau kode..."
              className="pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500 w-44 sm:w-60"
            />
          </div>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>+ Layanan Baru</span>
          </button>
        </div>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredServices.map(srv => (
          <div
            key={srv.id}
            className={`bg-white rounded-2xl border p-5 shadow-xs transition space-y-3 flex flex-col justify-between ${
              srv.status === 'active'
                ? 'border-slate-200/80 hover:border-cyan-400'
                : 'border-slate-200 bg-slate-50/70 opacity-60'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-cyan-700 bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200">
                  {srv.code}
                </span>
                <span
                  onClick={() => handleToggleStatus(srv)}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full cursor-pointer transition ${
                    srv.status === 'active'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {srv.status === 'active' ? 'Aktif' : 'Nonaktif'}
                </span>
              </div>

              <div>
                <h3 className="font-extrabold text-sm text-slate-900">{srv.name}</h3>
                {srv.description && (
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">{srv.description}</p>
                )}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="flex items-baseline justify-between">
                <span className="text-xs text-slate-400">Tarif:</span>
                <div className="text-right">
                  <span className="text-base font-black text-slate-900 font-mono">
                    {formatRupiah(srv.price)}
                  </span>
                  <span className="text-xs text-slate-500"> / {srv.unit}</span>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  {srv.durationHours || 24} Jam
                </span>

                <button
                  onClick={() => handleOpenEdit(srv)}
                  className="flex items-center gap-1 text-cyan-600 hover:text-cyan-700 font-bold p-1"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  Edit
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal Add / Edit Service */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editingService ? 'Edit Layanan Laundry' : 'Tambah Layanan Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kode Layanan
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.code || ''}
                    onChange={e => setFormData({ ...formData, code: e.target.value })}
                    placeholder="L001"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Satuan
                  </label>
                  <select
                    value={formData.unit || 'Kg'}
                    onChange={e => setFormData({ ...formData, unit: e.target.value as ServiceUnit })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="Kg">Kg (Kilogram)</option>
                    <option value="Pcs">Pcs (Satuan)</option>
                    <option value="Meter">Meter</option>
                    <option value="Pasang">Pasang (Sepatu)</option>
                    <option value="Paket">Paket</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nama Layanan
                </label>
                <input
                  type="text"
                  required
                  value={formData.name || ''}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Cth: Cuci + Setrika Reguler"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Harga / Tarif (Rp)
                  </label>
                  <input
                    type="number"
                    min="500"
                    step="500"
                    required
                    value={formData.price || ''}
                    onChange={e => setFormData({ ...formData, price: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Estimasi (Jam)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.durationHours || 24}
                    onChange={e => setFormData({ ...formData, durationHours: Number(e.target.value) || 24 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Kategori
                </label>
                <select
                  value={formData.category || 'kiloan'}
                  onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="kiloan">Kiloan</option>
                  <option value="satuan">Satuan</option>
                  <option value="express">Express / Kilat</option>
                  <option value="khusus">Khusus (Sepatu/Karpet)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Deskripsi / Keterangan
                </label>
                <textarea
                  rows={2}
                  value={formData.description || ''}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Keterangan proses pengerjaan..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                >
                  Simpan Layanan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
