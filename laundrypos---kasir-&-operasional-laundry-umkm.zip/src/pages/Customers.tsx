import React, { useState } from 'react';
import {
  UserPlus,
  Search,
  Phone,
  MapPin,
  FileText,
  Clock,
  Banknote,
  Share2,
  Edit2,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Trash2,
} from 'lucide-react';
import { Customer, StoreSettings, Transaction } from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo, formatDateTimeIndo } from '../utils/date';
import { CustomerModal } from '../components/CustomerModal';
import { StatusBadge } from '../components/StatusBadge';
import { PaymentStatusBadge } from '../components/PaymentStatusBadge';

interface Props {
  customers: Customer[];
  transactions: Transaction[];
  settings: StoreSettings;
  onSaveCustomer: (customer: Customer) => void;
  onDeleteCustomer?: (id: string) => void;
  onViewReceipt: (trx: Transaction) => void;
}

export const Customers: React.FC<Props> = ({
  customers,
  transactions,
  settings,
  onSaveCustomer,
  onDeleteCustomer,
  onViewReceipt,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDebtOnly, setFilterDebtOnly] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [selectedCustomerHistory, setSelectedCustomerHistory] = useState<Customer | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  const filteredCustomers = customers.filter(c => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      c.code.toLowerCase().includes(q) ||
      (c.address && c.address.toLowerCase().includes(q));

    const matchesDebt = filterDebtOnly ? (c.piutang_amount || 0) > 0 : true;
    return matchesSearch && matchesDebt;
  });

  const getCustomerTransactions = (customerId: string) => {
    return transactions.filter(t => t.customer_id === customerId);
  };

  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setIsModalOpen(true);
  };

  const handleWhatsApp = (customer: Customer) => {
    let phone = customer.phone.replace(/[^0-9]/g, '');
    if (phone.startsWith('0')) {
      phone = '62' + phone.substring(1);
    }
    const message = encodeURIComponent(
      `Halo Kak *${customer.name}*, terima kasih telah menjadi pelanggan setia di *${settings.store_name}*!`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900">Database Pelanggan</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar pelanggan, riwayat transaksi belanja, dan rekap piutang.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari nama, HP, alamat..."
              className="pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500 w-44 sm:w-60"
            />
          </div>

          {/* Filter debt toggle */}
          <button
            onClick={() => setFilterDebtOnly(!filterDebtOnly)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              filterDebtOnly
                ? 'bg-rose-100 text-rose-800 border border-rose-300'
                : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>Punya Piutang Saja</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Tambah Pelanggan</span>
          </button>
        </div>
      </div>

      {/* Customer Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCustomers.map(customer => {
          const custTrx = getCustomerTransactions(customer.id);
          const totalSpent = custTrx.reduce((acc, curr) => acc + curr.total, 0);
          const totalDebt = custTrx.reduce((acc, curr) => acc + (curr.debt_amount || 0), 0);

          return (
            <div
              key={customer.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-cyan-300 hover:shadow-md transition space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-100 text-cyan-700 font-extrabold flex items-center justify-center text-sm">
                      {customer.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{customer.name}</h3>
                      <div className="flex items-center gap-1 text-xs text-slate-500 font-mono">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{customer.phone || '-'}</span>
                      </div>
                    </div>
                  </div>

                  <span className="font-mono text-[11px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                    {customer.code}
                  </span>
                </div>

                {/* Address & Notes */}
                {customer.address && (
                  <div className="flex items-start gap-1.5 text-xs text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-1">{customer.address}</span>
                  </div>
                )}
                {customer.notes && (
                  <div className="text-[11px] text-slate-500 italic bg-slate-50 p-2 rounded-lg border border-slate-100 line-clamp-2">
                    "{customer.notes}"
                  </div>
                )}

                {/* Stats badge */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center">
                  <div>
                    <div className="text-[10px] text-slate-400 font-medium uppercase">Order</div>
                    <div className="font-bold text-xs text-slate-800 font-mono">
                      {custTrx.length || customer.total_transactions || 0}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-medium uppercase">Total Belanja</div>
                    <div className="font-bold text-xs text-slate-800 font-mono truncate">
                      {formatRupiah(totalSpent || customer.total_spent || 0)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-medium uppercase">Piutang</div>
                    <div
                      className={`font-bold text-xs font-mono truncate ${
                        totalDebt > 0 ? 'text-rose-600' : 'text-emerald-600'
                      }`}
                    >
                      {formatRupiah(totalDebt || customer.piutang_amount || 0)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  onClick={() => setSelectedCustomerHistory(customer)}
                  className="text-xs font-bold text-cyan-600 hover:text-cyan-700 flex items-center gap-1"
                >
                  <Clock className="w-3.5 h-3.5" /> Riwayat Order ({custTrx.length})
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleWhatsApp(customer)}
                    title="Kirim Pesan WhatsApp"
                    className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg border border-emerald-200 transition"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleOpenEdit(customer)}
                    title="Edit Pelanggan"
                    className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg border border-slate-200 transition"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  {onDeleteCustomer && (
                    <button
                      onClick={() => setCustomerToDelete(customer)}
                      title="Hapus Pelanggan"
                      className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg border border-rose-200 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredCustomers.length === 0 && (
        <div className="py-16 text-center text-slate-400 text-sm bg-white rounded-3xl border border-slate-200">
          Tidak ada pelanggan yang cocok dengan pencarian.
        </div>
      )}

      {/* Customer Modal (Add/Edit) */}
      <CustomerModal
        isOpen={isModalOpen}
        initialCustomer={editingCustomer}
        onClose={() => setIsModalOpen(false)}
        onSave={onSaveCustomer}
        onDelete={onDeleteCustomer}
      />

      {/* Delete Customer Confirmation Modal */}
      {customerToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-base text-slate-900">Hapus Data Pelanggan?</h3>
              <p className="text-xs text-slate-500">
                Apakah Anda yakin ingin menghapus pelanggan <b>{customerToDelete.name}</b> ({customerToDelete.code})? Data yang dihapus juga akan disinkronkan ke Google Spreadsheet.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="flex-1 py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteCustomer) {
                    onDeleteCustomer(customerToDelete.id);
                  }
                  setCustomerToDelete(null);
                }}
                className="flex-1 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Order History Modal */}
      {selectedCustomerHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-bold text-base">Riwayat Transaksi</h4>
                <p className="text-xs text-slate-400">
                  {selectedCustomerHistory.name} • {selectedCustomerHistory.phone}
                </p>
              </div>
              <button
                onClick={() => setSelectedCustomerHistory(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="p-6 max-h-96 overflow-y-auto space-y-3">
              {getCustomerTransactions(selectedCustomerHistory.id).length > 0 ? (
                getCustomerTransactions(selectedCustomerHistory.id).map(trx => (
                  <div
                    key={trx.id}
                    onClick={() => {
                      setSelectedCustomerHistory(null);
                      onViewReceipt(trx);
                    }}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-cyan-300 hover:bg-white cursor-pointer transition flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-slate-800">
                          {trx.invoice}
                        </span>
                        <StatusBadge status={trx.status} size="sm" />
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        {formatDateTimeIndo(trx.date)} • {trx.items.length} item
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-xs text-slate-900 font-mono">
                        {formatRupiah(trx.total)}
                      </div>
                      <PaymentStatusBadge status={trx.payment_status} size="sm" />
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-8 text-center text-xs text-slate-400">
                  Belum ada transaksi untuk pelanggan ini.
                </div>
              )}
            </div>

            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedCustomerHistory(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-lg"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
