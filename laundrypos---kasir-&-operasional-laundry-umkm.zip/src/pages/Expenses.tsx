import React, { useState } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Calendar,
  CreditCard,
  Trash2,
  TrendingDown,
  Tag,
  Wallet,
} from 'lucide-react';
import { Expense, ExpenseCategory, PaymentMethod, User as UserType } from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo } from '../utils/date';
import { playBeep } from '../utils/sound';

interface Props {
  expenses: Expense[];
  activeUser: UserType;
  onSaveExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
}

export const Expenses: React.FC<Props> = ({
  expenses,
  activeUser,
  onSaveExpense,
  onDeleteExpense,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState<Partial<Expense>>({
    date: new Date().toISOString().split('T')[0],
    category: 'Deterjen',
    description: '',
    amount: 50000,
    payment_method: 'cash',
  });

  const categories: ExpenseCategory[] = [
    'Listrik',
    'Air',
    'Deterjen',
    'Pewangi',
    'Plastik',
    'Gaji',
    'Sewa',
    'Transport',
    'Maintenance',
    'Lainnya',
  ];

  const filteredExpenses = expenses.filter(e => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      e.description.toLowerCase().includes(q) || e.category.toLowerCase().includes(q);
    const matchesCat = categoryFilter === 'all' || e.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const totalExpense = filteredExpenses.reduce((acc, curr) => acc + curr.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.description?.trim() || !formData.amount) return;

    playBeep('beep');
    onSaveExpense({
      id: `EXP-${Date.now()}`,
      date: formData.date ? new Date(formData.date).toISOString() : new Date().toISOString(),
      category: (formData.category as ExpenseCategory) || 'Lainnya',
      description: formData.description.trim(),
      amount: Number(formData.amount) || 0,
      payment_method: (formData.payment_method as PaymentMethod) || 'cash',
      created_by: activeUser.name,
    });

    setIsModalOpen(false);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      category: 'Deterjen',
      description: '',
      amount: 50000,
      payment_method: 'cash',
    });
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900">Biaya Operasional Usaha</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan pengeluaran deterjen, token listrik, tagihan air PDAM, plastik, dan gaji.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-100 px-4 py-2 rounded-xl text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400">Total Pengeluaran:</span>
            <div className="text-base font-black text-rose-600 font-mono">
              {formatRupiah(totalExpense)}
            </div>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-sm transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catat Biaya</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari keterangan atau kategori..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1">
          <button
            onClick={() => setCategoryFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
              categoryFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Semua
          </button>
          {categories.map(c => (
            <button
              key={c}
              onClick={() => setCategoryFilter(c)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                categoryFilter === c
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 uppercase font-bold tracking-wider border-b border-slate-200">
            <tr>
              <th className="py-3.5 px-4">Tanggal</th>
              <th className="py-3.5 px-4">Kategori</th>
              <th className="py-3.5 px-4">Keterangan Biaya</th>
              <th className="py-3.5 px-4">Metode Bayar</th>
              <th className="py-3.5 px-4 text-right">Nominal</th>
              <th className="py-3.5 px-4 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredExpenses.map(exp => (
              <tr key={exp.id} className="hover:bg-slate-50 transition">
                <td className="py-3.5 px-4 font-mono text-slate-600">
                  {formatDateIndo(exp.date)}
                </td>
                <td className="py-3.5 px-4">
                  <span className="font-bold text-slate-800 bg-slate-100 px-2.5 py-0.5 rounded-full border border-slate-200 text-[11px]">
                    {exp.category}
                  </span>
                </td>
                <td className="py-3.5 px-4 font-medium text-slate-800 max-w-sm">
                  {exp.description}
                  {exp.created_by && (
                    <span className="block text-[10px] text-slate-400 mt-0.5">
                      Dicatat: {exp.created_by}
                    </span>
                  )}
                </td>
                <td className="py-3.5 px-4 uppercase font-semibold text-slate-500 text-[11px]">
                  {exp.payment_method}
                </td>
                <td className="py-3.5 px-4 text-right font-mono font-bold text-rose-600 text-sm">
                  {formatRupiah(exp.amount)}
                </td>
                <td className="py-3.5 px-4 text-center">
                  <button
                    onClick={() => onDeleteExpense(exp.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition"
                    title="Hapus Pengeluaran"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredExpenses.length === 0 && (
          <div className="py-16 text-center text-slate-400 text-xs">
            Belum ada data pengeluaran tercatat.
          </div>
        )}
      </div>

      {/* Modal Add Expense */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-base">Catat Pengeluaran Baru</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.date || ''}
                    onChange={e => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Kategori
                  </label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-rose-500"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Keterangan Biaya
                </label>
                <input
                  type="text"
                  required
                  placeholder="Cth: Pembelian deterjen cair Oxy 20 Liter"
                  value={formData.description || ''}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Nominal Biaya (Rp)
                  </label>
                  <input
                    type="number"
                    min="1000"
                    step="1000"
                    required
                    value={formData.amount || ''}
                    onChange={e => setFormData({ ...formData, amount: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Metode Pembayaran
                  </label>
                  <select
                    value={formData.payment_method}
                    onChange={e => setFormData({ ...formData, payment_method: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-rose-500"
                  >
                    <option value="cash">Cash (Tunai)</option>
                    <option value="transfer">Transfer</option>
                    <option value="qris">QRIS</option>
                    <option value="ewallet">E-Wallet</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                >
                  Simpan Biaya
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
