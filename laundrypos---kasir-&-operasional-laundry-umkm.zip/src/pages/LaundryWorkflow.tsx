import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  Search,
  Filter,
  ArrowRight,
  Printer,
  Share2,
  Calendar,
  Layers,
  History,
  Tag,
  MapPin,
  ChevronRight,
  List,
  Kanban,
  Check,
  AlertCircle,
} from 'lucide-react';
import {
  LaundryStatus,
  StoreSettings,
  Transaction,
  User as UserType,
  UserRole,
} from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo, formatDateTimeIndo } from '../utils/date';
import { playBeep } from '../utils/sound';
import { STATUS_LABELS, STATUS_ORDER, StatusBadge } from '../components/StatusBadge';
import { PaymentStatusBadge } from '../components/PaymentStatusBadge';

interface Props {
  transactions: Transaction[];
  settings: StoreSettings;
  activeUser: UserType;
  currentRole: UserRole;
  onUpdateStatus: (transactionId: string, status: LaundryStatus, notes?: string) => void;
  onViewReceipt: (trx: Transaction) => void;
}

export const LaundryWorkflow: React.FC<Props> = ({
  transactions,
  settings,
  activeUser,
  currentRole,
  onUpdateStatus,
  onViewReceipt,
}) => {
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');
  const [selectedHistoryTrx, setSelectedHistoryTrx] = useState<Transaction | null>(null);

  // Filtered transactions
  const filteredTransactions = transactions.filter(t => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      t.invoice.toLowerCase().includes(q) ||
      t.customer_name.toLowerCase().includes(q) ||
      t.customer_phone.includes(q) ||
      (t.rack_location && t.rack_location.toLowerCase().includes(q));

    const matchesStatus =
      selectedStatusFilter === 'all'
        ? true
        : selectedStatusFilter === 'aktif'
        ? t.status !== 'selesai'
        : t.status === selectedStatusFilter;

    return matchesSearch && matchesStatus;
  });

  const getNextStatus = (current: LaundryStatus): LaundryStatus | null => {
    const idx = STATUS_ORDER.indexOf(current);
    if (idx >= 0 && idx < STATUS_ORDER.length - 1) {
      return STATUS_ORDER[idx + 1];
    }
    return null;
  };

  const handleAdvanceStatus = (trx: Transaction, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = getNextStatus(trx.status);
    if (next) {
      playBeep('beep');
      onUpdateStatus(trx.id, next, `Diubah ke ${STATUS_LABELS[next]} oleh ${activeUser.name}`);
    }
  };

  const handleSendReadyNotification = (trx: Transaction, e: React.MouseEvent) => {
    e.stopPropagation();
    let phone = trx.customer_phone.replace(/[^0-9]/g, '');
    if (phone.startsWith('0')) {
      phone = '62' + phone.substring(1);
    }

    const message = encodeURIComponent(
      `*NOTIFIKASI LAUNDRY SIAP DIAMBIL - ${settings.store_name}*\n` +
      `Halo Kak *${trx.customer_name}*,\n` +
      `Cucian Anda dengan No. Nota *${trx.invoice}* telah SELESAI, bersih, wangi, dan SIAP DIAMBIL di outlet kami.\n\n` +
      `📦 Layanan: ${trx.items.map(i => `${i.service_name} (${i.qty} ${i.unit})`).join(', ')}\n` +
      (trx.rack_location ? `🏷️ Posisi Rak: *${trx.rack_location}*\n` : '') +
      (trx.debt_amount > 0
        ? `⚠️ *Sisa Pembayaran: ${formatRupiah(trx.debt_amount)}*\n`
        : `✅ *Status Pembayaran: LUNAS*\n`) +
      `\nSilakan bawa nota ini atau tunjukkan pesan ini ke kasir. Terima kasih!`
    );

    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-slate-900">Operasional & Status Laundry</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola alur pengerjaan cucian dari penerimaan hingga pakaian diserahkan ke pelanggan.
          </p>
        </div>

        {/* View mode toggle + search */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari nota, pelanggan, rak..."
              className="pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500 w-44 sm:w-56"
            />
          </div>

          {/* Quick status filter */}
          <select
            value={selectedStatusFilter}
            onChange={e => setSelectedStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500"
          >
            <option value="all">Semua Status</option>
            <option value="aktif">Aktif Saja (Belum Selesai)</option>
            {STATUS_ORDER.map(st => (
              <option key={st} value={st}>
                {STATUS_LABELS[st]}
              </option>
            ))}
          </select>

          {/* View mode buttons */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-1.5 rounded-lg transition ${
                viewMode === 'kanban'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Kanban Board"
            >
              <Kanban className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition ${
                viewMode === 'table'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
              title="Tabel Detail"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* KANBAN BOARD VIEW */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3.5 items-start overflow-x-auto pb-4">
          {STATUS_ORDER.map(status => {
            const listInStatus = filteredTransactions.filter(t => t.status === status);
            return (
              <div
                key={status}
                className="bg-slate-100/70 border border-slate-200/80 rounded-2xl p-3 flex flex-col min-w-[210px]"
              >
                {/* Stage Header */}
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-xs text-slate-800 uppercase tracking-wider">
                      {STATUS_LABELS[status]}
                    </span>
                  </div>
                  <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded-full bg-white text-slate-700 shadow-xs">
                    {listInStatus.length}
                  </span>
                </div>

                {/* Cards in stage */}
                <div className="space-y-2.5 min-h-[300px]">
                  {listInStatus.map(trx => {
                    const next = getNextStatus(trx.status);
                    return (
                      <div
                        key={trx.id}
                        onClick={() => onViewReceipt(trx)}
                        className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-xs hover:border-cyan-400 hover:shadow-md transition cursor-pointer space-y-2 group"
                      >
                        <div className="flex items-start justify-between">
                          <span className="font-mono font-bold text-xs text-slate-500 group-hover:text-cyan-600 transition">
                            {trx.invoice}
                          </span>
                          <PaymentStatusBadge status={trx.payment_status} size="sm" />
                        </div>

                        <div>
                          <div className="font-bold text-xs text-slate-900 line-clamp-1">
                            {trx.customer_name}
                          </div>
                          <div className="text-[11px] text-slate-500 line-clamp-1">
                            {trx.items.map(i => `${i.service_name} (${i.qty}${i.unit})`).join(', ')}
                          </div>
                        </div>

                        {trx.rack_location && (
                          <div className="flex items-center gap-1 text-[10px] font-semibold text-slate-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                            <MapPin className="w-3 h-3 text-cyan-600" />
                            <span>{trx.rack_location}</span>
                          </div>
                        )}

                        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100 font-mono">
                          <span>{formatRupiah(trx.total)}</span>
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              setSelectedHistoryTrx(trx);
                            }}
                            title="Riwayat Status"
                            className="p-1 hover:text-cyan-600"
                          >
                            <History className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Quick action button for Operator */}
                        {next && (
                          <button
                            onClick={e => handleAdvanceStatus(trx, e)}
                            className="w-full mt-1 py-1.5 bg-slate-50 hover:bg-cyan-50 hover:text-cyan-700 text-slate-700 font-bold text-[11px] rounded-lg border border-slate-200 flex items-center justify-center gap-1 transition"
                          >
                            <span>Lanjut {STATUS_LABELS[next]}</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* WhatsApp button when ready */}
                        {trx.status === 'siap_diambil' && (
                          <button
                            onClick={e => handleSendReadyNotification(trx, e)}
                            className="w-full mt-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-lg shadow-xs flex items-center justify-center gap-1 transition"
                          >
                            <Share2 className="w-3 h-3" />
                            <span>Kirim WA Siap Diambil</span>
                          </button>
                        )}
                      </div>
                    );
                  })}

                  {listInStatus.length === 0 && (
                    <div className="py-10 text-center text-[11px] text-slate-400 italic">
                      Kosong
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 uppercase font-bold tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">No. Invoice</th>
                  <th className="py-3.5 px-4">Pelanggan</th>
                  <th className="py-3.5 px-4">Rincian Cucian</th>
                  <th className="py-3.5 px-4">Rak / Posisi</th>
                  <th className="py-3.5 px-4">Total & Bayar</th>
                  <th className="py-3.5 px-4">Status Proses</th>
                  <th className="py-3.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.map(trx => {
                  const next = getNextStatus(trx.status);
                  return (
                    <tr
                      key={trx.id}
                      onClick={() => onViewReceipt(trx)}
                      className="hover:bg-slate-50/80 cursor-pointer transition"
                    >
                      <td className="py-3.5 px-4">
                        <div className="font-mono font-bold text-slate-900">{trx.invoice}</div>
                        <div className="text-[11px] text-slate-400">
                          {formatDateTimeIndo(trx.date)}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{trx.customer_name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {trx.customer_phone}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="text-slate-700">
                          {trx.items.map(i => `${i.service_name} (${i.qty} ${i.unit})`).join(', ')}
                        </div>
                        {trx.perfume_choice && (
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Parfum: {trx.perfume_choice}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        {trx.rack_location ? (
                          <span className="font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                            {trx.rack_location}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-mono">
                        <div className="font-bold text-slate-900">{formatRupiah(trx.total)}</div>
                        <PaymentStatusBadge status={trx.payment_status} size="sm" />
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusBadge status={trx.status} size="sm" />
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              setSelectedHistoryTrx(trx);
                            }}
                            className="p-1.5 text-slate-500 hover:text-cyan-600 rounded-lg hover:bg-slate-100"
                            title="Riwayat Status"
                          >
                            <History className="w-4 h-4" />
                          </button>
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              onViewReceipt(trx);
                            }}
                            className="p-1.5 text-slate-500 hover:text-cyan-600 rounded-lg hover:bg-slate-100"
                            title="Cetak Nota"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          {next && (
                            <button
                              onClick={e => handleAdvanceStatus(trx, e)}
                              className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold rounded-lg transition"
                            >
                              Lanjut {STATUS_LABELS[next]}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* History Timeline Modal as specified in PRD Section 7 */}
      {selectedHistoryTrx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-bold text-base">Riwayat Pengerjaan Laundry</h4>
                <p className="text-xs text-slate-400 font-mono">{selectedHistoryTrx.invoice}</p>
              </div>
              <button
                onClick={() => setSelectedHistoryTrx(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="border-l-2 border-cyan-500 ml-3 pl-4 space-y-4">
                {(selectedHistoryTrx.status_history || []).map((sh, idx) => (
                  <div key={idx} className="relative group">
                    <div className="w-3 h-3 rounded-full bg-cyan-500 absolute -left-[22px] top-1 ring-4 ring-white" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs uppercase text-slate-900">
                          {STATUS_LABELS[sh.status]}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {formatDateTimeIndo(sh.timestamp)}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 mt-0.5">
                        Oleh: <span className="font-semibold text-slate-800">{sh.user_name}</span>
                      </div>
                      {sh.notes && (
                        <div className="text-[11px] text-slate-500 italic mt-0.5">{sh.notes}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedHistoryTrx(null)}
                className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-lg"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
