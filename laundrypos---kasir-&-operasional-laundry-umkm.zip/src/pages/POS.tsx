import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  UserPlus,
  Plus,
  Minus,
  Trash2,
  Check,
  ShoppingBag,
  Sparkles,
  CreditCard,
  User,
  Phone,
  Clock,
  Tag,
  AlertCircle,
  Percent,
  Calendar,
  Layers,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  Customer,
  PaymentMethod,
  Service,
  SplitPaymentRecord,
  StoreSettings,
  Transaction,
  TransactionItem,
  User as UserType,
} from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo } from '../utils/date';
import { playBeep } from '../utils/sound';
import { CustomerModal } from '../components/CustomerModal';
import { PaymentModal } from '../components/PaymentModal';

interface Props {
  services: Service[];
  customers: Customer[];
  settings: StoreSettings;
  activeUser: UserType;
  onSaveTransaction: (trx: Transaction) => void;
  onSaveCustomer: (customer: Customer) => void;
  onShowReceipt: (trx: Transaction) => void;
}

export const POS: React.FC<Props> = ({
  services,
  customers,
  settings,
  activeUser,
  onSaveTransaction,
  onSaveCustomer,
  onShowReceipt,
}) => {
  // POS States
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerSearch, setCustomerSearch] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);

  // Cart
  const [cartItems, setCartItems] = useState<TransactionItem[]>([]);
  const [discount, setDiscount] = useState<number>(0);
  const [perfumeChoice, setPerfumeChoice] = useState<string>(settings.default_perfume || 'Lavender');
  const [rackLocation, setRackLocation] = useState<string>('');
  const [orderNotes, setOrderNotes] = useState<string>('');
  const [turnaroundDays, setTurnaroundDays] = useState<number>(2);

  // Search & Filter Services
  const [serviceSearch, setServiceSearch] = useState('');
  const [serviceCategory, setServiceCategory] = useState<string>('all');

  // Payment modal state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  // Input references for keyboard shortcuts
  const customerInputRef = useRef<HTMLInputElement>(null);
  const serviceInputRef = useRef<HTMLInputElement>(null);

  // Load default customer or set up shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // F2: Transaksi Baru
      if (e.key === 'F2') {
        e.preventDefault();
        handleResetPOS();
      }
      // F3: Cari Pelanggan
      if (e.key === 'F3') {
        e.preventDefault();
        customerInputRef.current?.focus();
        setShowCustomerDropdown(true);
      }
      // F4: Cari Layanan
      if (e.key === 'F4') {
        e.preventDefault();
        serviceInputRef.current?.focus();
      }
      // F5: Pembayaran
      if (e.key === 'F5') {
        e.preventDefault();
        if (cartItems.length > 0 && selectedCustomer) {
          setIsPaymentModalOpen(true);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cartItems, selectedCustomer]);

  // Cart Totals
  const subtotal = cartItems.reduce((acc, curr) => acc + curr.subtotal, 0);
  const total = Math.max(0, subtotal - discount);

  // Filtered Customers
  const filteredCustomers = customers.filter(
    c =>
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.phone.includes(customerSearch) ||
      c.code.toLowerCase().includes(customerSearch.toLowerCase())
  );

  // Filtered Services
  const filteredServices = services.filter(s => {
    const matchesSearch =
      s.name.toLowerCase().includes(serviceSearch.toLowerCase()) ||
      s.code.toLowerCase().includes(serviceSearch.toLowerCase());
    const matchesCat = serviceCategory === 'all' || s.category === serviceCategory;
    return matchesSearch && matchesCat && s.status === 'active';
  });

  // Add service to cart
  const handleAddService = (service: Service) => {
    playBeep('beep');
    setCartItems(prev => {
      const existing = prev.find(item => item.service_id === service.id);
      if (existing) {
        // increment by 1
        return prev.map(item =>
          item.service_id === service.id
            ? {
                ...item,
                qty: Number((item.qty + 1).toFixed(2)),
                subtotal: Math.round((item.qty + 1) * item.price),
              }
            : item
        );
      } else {
        // default 1 or 3 for kiloan
        const defaultQty = service.unit === 'Kg' ? 1 : 1;
        return [
          ...prev,
          {
            id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            service_id: service.id,
            service_code: service.code,
            service_name: service.name,
            qty: defaultQty,
            unit: service.unit,
            price: service.price,
            subtotal: defaultQty * service.price,
          },
        ];
      }
    });
  };

  const handleUpdateQty = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.id === itemId
          ? {
              ...item,
              qty: newQty,
              subtotal: Math.round(newQty * item.price),
            }
          : item
      )
    );
  };

  const handleRemoveItem = (itemId: string) => {
    playBeep('beep');
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const handleResetPOS = () => {
    setSelectedCustomer(null);
    setCustomerSearch('');
    setCartItems([]);
    setDiscount(0);
    setOrderNotes('');
    setRackLocation('');
    playBeep('beep');
  };

  // Quick Customer Creation
  const handleNewCustomerCreated = (newCust: Customer) => {
    onSaveCustomer(newCust);
    setSelectedCustomer(newCust);
    setCustomerSearch(newCust.name);
    setShowCustomerDropdown(false);
  };

  // Complete & Save Transaction
  const handleCompleteTransaction = (
    paymentMethods: SplitPaymentRecord[],
    paidAmount: number,
    debtAmount: number,
    changeAmount: number,
    paymentStatus: 'lunas' | 'sebagian' | 'belum_lunas'
  ) => {
    if (!selectedCustomer || cartItems.length === 0) return;

    const now = new Date();
    const estDate = new Date(now.getTime() + turnaroundDays * 86400000);
    const invoiceNumber = `TRX-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newTransaction: Transaction = {
      id: `trx-${Date.now()}`,
      invoice: invoiceNumber,
      customer_id: selectedCustomer.id,
      customer_name: selectedCustomer.name,
      customer_phone: selectedCustomer.phone,
      customer_address: selectedCustomer.address,
      date: now.toISOString(),
      estimated_completion_date: estDate.toISOString(),
      items: cartItems,
      subtotal,
      discount,
      total,
      paid_amount: paidAmount,
      debt_amount: debtAmount,
      change_amount: changeAmount,
      payment_status: paymentStatus,
      payment_methods: paymentMethods,
      status: 'diterima',
      status_history: [
        {
          id: `sh-${Date.now()}`,
          status: 'diterima',
          timestamp: now.toISOString(),
          user_name: activeUser.name,
          notes: 'Transaksi dicatat di kasir',
        },
      ],
      rack_location: rackLocation.trim() || undefined,
      perfume_choice: perfumeChoice,
      notes: orderNotes.trim() || undefined,
      created_by: activeUser.name,
    };

    onSaveTransaction(newTransaction);
    setIsPaymentModalOpen(false);

    // Confetti effect
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }

    // Reset and immediately show receipt
    handleResetPOS();
    onShowReceipt(newTransaction);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* LEFT COLUMN: Customer Selection & Services Catalog (7 cols) */}
      <div className="lg:col-span-7 space-y-4">
        {/* Customer Box */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-4 h-4 text-cyan-600" />
              1. Pilih Pelanggan (F3)
            </label>
            <button
              onClick={() => setIsAddCustomerOpen(true)}
              className="text-xs font-bold text-cyan-600 hover:text-cyan-700 flex items-center gap-1 bg-cyan-50 hover:bg-cyan-100 px-2.5 py-1 rounded-lg transition"
            >
              <UserPlus className="w-3.5 h-3.5" /> + Pelanggan Baru
            </button>
          </div>

          <div className="relative">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                ref={customerInputRef}
                type="text"
                value={customerSearch}
                onChange={e => {
                  setCustomerSearch(e.target.value);
                  setShowCustomerDropdown(true);
                  if (selectedCustomer && e.target.value !== selectedCustomer.name) {
                    setSelectedCustomer(null);
                  }
                }}
                onFocus={() => setShowCustomerDropdown(true)}
                placeholder="Ketik nama atau nomor HP pelanggan..."
                className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"
              />
              {selectedCustomer && (
                <button
                  onClick={() => {
                    setSelectedCustomer(null);
                    setCustomerSearch('');
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-bold p-1"
                >
                  Ganti
                </button>
              )}
            </div>

            {/* Dropdown suggestions */}
            {showCustomerDropdown && !selectedCustomer && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-xl border border-slate-200 z-20 max-h-60 overflow-y-auto">
                {filteredCustomers.length > 0 ? (
                  filteredCustomers.map(c => (
                    <div
                      key={c.id}
                      onClick={() => {
                        setSelectedCustomer(c);
                        setCustomerSearch(c.name);
                        setShowCustomerDropdown(false);
                      }}
                      className="p-3 hover:bg-cyan-50/70 border-b border-slate-100 last:border-0 cursor-pointer transition flex items-center justify-between"
                    >
                      <div>
                        <div className="font-bold text-sm text-slate-900">{c.name}</div>
                        <div className="text-xs text-slate-500 font-mono flex items-center gap-2">
                          <span>{c.phone}</span>
                          {c.address && <span>• {c.address}</span>}
                        </div>
                      </div>
                      <div className="text-right">
                        {c.piutang_amount && c.piutang_amount > 0 ? (
                          <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
                            Piutang: {formatRupiah(c.piutang_amount)}
                          </span>
                        ) : (
                          <span className="text-[11px] text-emerald-600 font-medium">Lunas</span>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-slate-500">
                    Pelanggan tidak ditemukan.{' '}
                    <button
                      onClick={() => setIsAddCustomerOpen(true)}
                      className="text-cyan-600 font-bold underline"
                    >
                      Tambah Baru
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Selected Customer banner with debt reminder if any */}
          {selectedCustomer && (
            <div className="mt-3 p-3 bg-cyan-50/60 border border-cyan-200 rounded-2xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-600 text-white font-bold flex items-center justify-center">
                  {selectedCustomer.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-slate-900">{selectedCustomer.name}</div>
                  <div className="text-slate-600 font-mono">{selectedCustomer.phone}</div>
                </div>
              </div>

              {selectedCustomer.piutang_amount && selectedCustomer.piutang_amount > 0 ? (
                <div className="flex items-center gap-1.5 bg-rose-100 text-rose-800 px-3 py-1 rounded-xl font-bold">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>Ada Piutang: {formatRupiah(selectedCustomer.piutang_amount)}</span>
                </div>
              ) : (
                <span className="text-emerald-700 font-semibold bg-emerald-100/70 px-2.5 py-1 rounded-xl">
                  Pelanggan Bersih
                </span>
              )}
            </div>
          )}
        </div>

        {/* Services Catalog */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-cyan-600" />
              2. Pilih Layanan Laundry (F4)
            </label>

            {/* Category tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              {[
                { id: 'all', label: 'Semua' },
                { id: 'kiloan', label: 'Kiloan' },
                { id: 'satuan', label: 'Satuan' },
                { id: 'express', label: 'Kilat' },
                { id: 'khusus', label: 'Khusus' },
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setServiceCategory(cat.id)}
                  className={`px-3 py-1 rounded-lg transition ${
                    serviceCategory === cat.id
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Service Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              ref={serviceInputRef}
              type="text"
              value={serviceSearch}
              onChange={e => setServiceSearch(e.target.value)}
              placeholder="Cari kode atau nama layanan (misal: Cuci Setrika, Bed Cover)..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-2xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {filteredServices.map(srv => {
              const inCart = cartItems.find(i => i.service_id === srv.id);
              return (
                <button
                  key={srv.id}
                  onClick={() => handleAddService(srv)}
                  className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between relative group hover:scale-[1.01] active:scale-95 ${
                    inCart
                      ? 'border-cyan-500 bg-cyan-50/50 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-cyan-300 hover:bg-slate-50'
                  }`}
                >
                  {inCart && (
                    <span className="absolute top-2 right-2 bg-cyan-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      {inCart.qty} {inCart.unit}
                    </span>
                  )}
                  <div>
                    <span className="text-[10px] font-mono font-bold text-slate-400">
                      {srv.code}
                    </span>
                    <h4 className="font-bold text-xs text-slate-900 line-clamp-1 mt-0.5">
                      {srv.name}
                    </h4>
                  </div>
                  <div className="mt-3 flex items-baseline justify-between">
                    <span className="text-xs font-extrabold text-cyan-700">
                      {formatRupiah(srv.price)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">/{srv.unit}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Transaction Cart & Summary (5 cols) */}
      <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-md space-y-5 sticky top-20">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-100 text-cyan-700 flex items-center justify-center font-bold">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">Rincian Cucian</h3>
              <p className="text-xs text-slate-400">Keranjang transaksi pelanggan</p>
            </div>
          </div>
          <button
            onClick={handleResetPOS}
            title="Reset Keranjang (F2)"
            className="text-xs font-bold text-rose-500 hover:text-rose-700 p-1 rounded"
          >
            Reset (F2)
          </button>
        </div>

        {/* Cart Items List */}
        <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
          {cartItems.length > 0 ? (
            cartItems.map(item => (
              <div
                key={item.id}
                className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h5 className="font-bold text-xs text-slate-900">{item.service_name}</h5>
                    <span className="text-[11px] text-slate-500">
                      {formatRupiah(item.price)} / {item.unit}
                    </span>
                  </div>
                  <button
                    onClick={() => handleRemoveItem(item.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Qty controller + Subtotal */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        handleUpdateQty(
                          item.id,
                          Number(Math.max(0.1, item.qty - (item.unit === 'Kg' ? 0.5 : 1)).toFixed(2))
                        )
                      }
                      className="w-6 h-6 rounded-lg bg-white border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100"
                    >
                      <Minus className="w-3 h-3" />
                    </button>

                    <div className="relative">
                      <input
                        type="number"
                        step={item.unit === 'Kg' ? '0.1' : '1'}
                        min="0.1"
                        value={item.qty}
                        onChange={e =>
                          handleUpdateQty(item.id, Number(parseFloat(e.target.value) || 0))
                        }
                        className="w-16 px-1.5 py-0.5 text-center font-bold text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
                      />
                    </div>
                    <span className="text-xs font-semibold text-slate-500">{item.unit}</span>

                    <button
                      onClick={() =>
                        handleUpdateQty(
                          item.id,
                          Number((item.qty + (item.unit === 'Kg' ? 0.5 : 1)).toFixed(2))
                        )
                      }
                      className="w-6 h-6 rounded-lg bg-white border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="font-extrabold text-sm text-slate-900 font-mono">
                    {formatRupiah(item.subtotal)}
                  </div>
                </div>

                {/* Notes per item */}
                <input
                  type="text"
                  placeholder="Catatan khusus pakaian (cth: jangan digosok panas)..."
                  value={item.notes || ''}
                  onChange={e => {
                    const val = e.target.value;
                    setCartItems(prev =>
                      prev.map(i => (i.id === item.id ? { ...i, notes: val } : i))
                    );
                  }}
                  className="w-full px-2 py-1 text-[11px] bg-white border border-slate-200 rounded-lg text-slate-600 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-2xl">
              Keranjang masih kosong. Klik layanan di sebelah kiri untuk menambahkan.
            </div>
          )}
        </div>

        {/* Operational Options: Perfume, Rak, Estimasi */}
        <div className="space-y-3 pt-2 border-t border-slate-100 text-xs">
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Pewangi / Parfum
              </label>
              <select
                value={perfumeChoice}
                onChange={e => setPerfumeChoice(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value="Lavender">Lavender (Calm)</option>
                <option value="Snappy">Snappy (Fresh Populer)</option>
                <option value="Akasia">Akasia (Mewah)</option>
                <option value="Downy Merah">Downy Merah (Sweet)</option>
                <option value="Fresh Ocean">Fresh Ocean (Sporty)</option>
                <option value="Tanpa Parfum">Tanpa Parfum (Netral)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Lokasi Rak / Keranjang
              </label>
              <input
                type="text"
                value={rackLocation}
                onChange={e => setRackLocation(e.target.value)}
                placeholder="Cth: Rak A-02"
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Estimasi Selesai
              </label>
              <select
                value={turnaroundDays}
                onChange={e => setTurnaroundDays(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-cyan-500"
              >
                <option value={0}>Hari ini (Kilat/Express)</option>
                <option value={1}>Besok (1 Hari / 24 Jam)</option>
                <option value={2}>Lusa (2 Hari / 48 Jam Standar)</option>
                <option value={3}>3 Hari (Karpet / Khusus)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Potongan / Diskon (Rp)
              </label>
              <input
                type="number"
                min="0"
                step="1000"
                value={discount || ''}
                onChange={e => setDiscount(Number(e.target.value) || 0)}
                placeholder="0"
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* Financial Calculation */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal</span>
            <span className="font-mono font-bold">{formatRupiah(subtotal)}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-medium">
              <span>Diskon</span>
              <span className="font-mono font-bold">-{formatRupiah(discount)}</span>
            </div>
          )}
          <div className="flex justify-between items-center pt-2 border-t border-slate-200">
            <span className="text-sm font-extrabold text-slate-900">TOTAL TAGIHAN</span>
            <span className="text-xl font-black text-cyan-700 font-mono">
              {formatRupiah(total)}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          <button
            disabled={cartItems.length === 0 || !selectedCustomer}
            onClick={() => setIsPaymentModalOpen(true)}
            className="w-full py-3.5 bg-cyan-600 hover:bg-cyan-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-cyan-600/20 transition active:scale-95 flex items-center justify-center gap-2"
          >
            <CreditCard className="w-4 h-4" />
            Bayar & Simpan (F5)
          </button>

          <button
            disabled={cartItems.length === 0 || !selectedCustomer}
            onClick={() =>
              handleCompleteTransaction(
                [{ method: 'piutang', amount: 0 }],
                0,
                total,
                0,
                'belum_lunas'
              )
            }
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 font-bold text-xs rounded-xl transition"
          >
            Simpan Nanti (Piutang Penuh / Bayar Saat Ambil)
          </button>
        </div>
      </div>

      {/* Customer Create Modal */}
      <CustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => setIsAddCustomerOpen(false)}
        onSave={handleNewCustomerCreated}
      />

      {/* Payment Modal */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        totalAmount={total}
        customerName={selectedCustomer?.name || 'Pelanggan'}
        onClose={() => setIsPaymentModalOpen(false)}
        onConfirm={handleCompleteTransaction}
      />
    </div>
  );
};
