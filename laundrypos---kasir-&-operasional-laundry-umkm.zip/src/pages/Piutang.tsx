import React, { useState } from 'react';
import {
  AlertCircle,
  Banknote,
  Search,
  CheckCircle2,
  Share2,
  Phone,
  Calendar,
  CreditCard,
  Printer,
  ChevronRight,
  Trash2,
} from 'lucide-react';
import { Customer, PaymentMethod, StoreSettings, Transaction } from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo } from '../utils/date';
import { playBeep } from '../utils/sound';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  transactions: Transaction[];
  customers: Customer[];
  settings: StoreSettings;
  onSettleDebt: (transactionId: string, amount: number, method: PaymentMethod) => void;
  onDeleteDebtTransaction?: (transactionId: string) => void;
  onViewReceipt: (trx: Transaction) => void;
}

export const Piutang: React.FC<Props> = ({
  transactions,
  customers,
  settings,
  onSettleDebt,
  onDeleteDebtTransaction,
  onViewReceipt,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTrxForSettle, setSelectedTrxForSettle] = useState<Transaction | null>(null);
  const [settleAmount, setSettleAmount] = useState<number>(0);
  const [settleMethod, setSettleMethod] = useState<PaymentMethod>('cash');
  const [trxToDeleteDebt, setTrxToDeleteDebt] = useState<Transaction | null>(null);

  // Transactions with outstanding debt
  const unpaidTransactions = transactions.filter(t => (t.debt_amount || 0) > 0);
  const totalOutstandingPiutang = unpaidTransactions.reduce(
    (acc, curr) => acc + (curr.debt_amount || 0),
    0
  );

  const filteredUnpaid = unpaidTransactions.filter(
    t =>
      t.invoice.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.customer_phone.includes(searchQuery)
  );

  const handleOpenSettle = (trx: Transaction) => {
    setSelectedTrxForSettle(trx);
    setSettleAmount(trx.debt_amount);
    setSettleMethod('cash');
  };

  const handleConfirmSettle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTrxForSettle || settleAmount <= 0) return;

    playBeep('cash');
    onSettleDebt(selectedTrxForSettle.id, settleAmount, settleMethod);
    setSelectedTrxForSettle(null);
  };

  const handleSendReminderWA = (trx: Transaction) => {
    let phone = trx.customer_phone.replace(/[^0-9]/g, '');
    if (phone.startsWith('0')) {
      phone = '62' + phone.substring(1);
    }

    const message = encodeURIComponent(
      `*PENGINGAT TAGIHAN LAUNDRY - ${settings.store_name}*\n` +
      `Halo Kak *${trx.customer_name}*,\n` +
      `Menginformasikan bahwa nota transaksi *${trx.invoice}* masih memiliki sisa piutang sebesar *${formatRupiah(trx.debt_amount)}*.\n\n` +
      `Total Tagihan: ${formatRupiah(trx.total)}\n` +
      `Telah Dibayar: ${formatRupiah(trx.paid_amount)}\n` +
      `*Sisa yang Belum Dibayar: ${formatRupiah(trx.debt_amount)}*\n\n` +
      `Pembayaran dapat ditransfer atau dibayar tunai/QRIS saat pengambilan pakaian. Terima kasih!`
    );

    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 p-6 rounded-3xl text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs uppercase font-bold tracking-widest text-rose-300">
            <AlertCircle className="w-4 h-4" /> Manajemen Piutang Usaha
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1">
            Total Piutang Belum Lunas
          </h1>
          <p className="text-rose-200/80 text-xs mt-1">
            Daftar tagihan yang belum dibayar penuh oleh pelanggan saat pembuatan nota.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 text-right">
          <div className="text-xs uppercase text-rose-200 font-semibold tracking-wider">
            Total Tagihan Tertahan
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-0.5">
            {formatRupiah(totalOutstandingPiutang)}
          </div>
          <div className="text-[11px] text-rose-200 mt-0.5">
            {unpaidTransactions.length} nota transaksi belum lunas
          </div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari nama pelanggan, nota, atau nomor HP..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
          />
        </div>

        <div className="text-xs font-semibold text-slate-500">
          Menampilkan <span className="text-slate-900 font-bold">{filteredUnpaid.length}</span> transaksi
        </div>
      </div>

      {/* Piutang Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-rose-50/50 text-slate-700 uppercase font-bold tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">No. Invoice & Tanggal</th>
                <th className="py-3.5 px-4">Pelanggan</th>
                <th className="py-3.5 px-4">Status Cucian</th>
                <th className="py-3.5 px-4 text-right">Total Nota</th>
                <th className="py-3.5 px-4 text-right">Sudah Dibayar</th>
                <th className="py-3.5 px-4 text-right text-rose-600">Sisa Piutang</th>
                <th className="py-3.5 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUnpaid.map(trx => (
                <tr key={trx.id} className="hover:bg-slate-50 transition">
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => onViewReceipt(trx)}
                      className="font-mono font-bold text-slate-900 hover:text-cyan-600 transition"
                    >
                      {trx.invoice}
                    </button>
                    <div className="text-[11px] text-slate-400">{formatDateIndo(trx.date)}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900">{trx.customer_name}</div>
                    <div className="text-[11px] text-slate-500 font-mono">{trx.customer_phone}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <StatusBadge status={trx.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-700">
                    {formatRupiah(trx.total)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-500">
                    {formatRupiah(trx.paid_amount)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-black text-rose-600 text-sm">
                    {formatRupiah(trx.debt_amount)}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => handleSendReminderWA(trx)}
                        title="Kirim Pengingat WhatsApp"
                        className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg border border-emerald-200 transition"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleOpenSettle(trx)}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition active:scale-95 flex items-center gap-1"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Pelunasan</span>
                      </button>

                      {onDeleteDebtTransaction && (
                        <button
                          type="button"
                          onClick={() => setTrxToDeleteDebt(trx)}
                          title="Hapus Transaksi Piutang"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 hover:border-rose-200 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredUnpaid.length === 0 && (
          <div className="py-16 text-center text-slate-400 text-sm">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            Luar biasa! Tidak ada piutang yang belum lunas.
          </div>
        )}
      </div>

      {/* Modal Pelunasan Piutang */}
      {selectedTrxForSettle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-6 py-4 bg-rose-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-bold text-base">Pelunasan Piutang</h4>
                <p className="text-xs text-rose-200 font-mono">{selectedTrxForSettle.invoice}</p>
              </div>
              <button
                onClick={() => setSelectedTrxForSettle(null)}
                className="p-1.5 text-rose-300 hover:text-white rounded-lg hover:bg-rose-800"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmSettle} className="p-6 space-y-4">
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Pelanggan:</span>
                  <span className="font-bold text-slate-900">{selectedTrxForSettle.customer_name}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Total Tagihan:</span>
                  <span>{formatRupiah(selectedTrxForSettle.total)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Telah Dibayar:</span>
                  <span>{formatRupiah(selectedTrxForSettle.paid_amount)}</span>
                </div>
                <div className="flex justify-between font-bold text-rose-700 text-sm pt-1 border-t border-rose-200">
                  <span>Sisa Piutang:</span>
                  <span>{formatRupiah(selectedTrxForSettle.debt_amount)}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nominal Pembayaran Pelunasan
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                    Rp
                  </span>
                  <input
                    type="number"
                    min="1000"
                    max={selectedTrxForSettle.debt_amount}
                    step="1000"
                    value={settleAmount || ''}
                    onChange={e => setSettleAmount(Number(e.target.value) || 0)}
                    required
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-base font-bold font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setSettleAmount(selectedTrxForSettle.debt_amount)}
                  className="mt-1 text-xs text-rose-600 font-bold hover:underline"
                >
                  Lunasi Penuh ({formatRupiah(selectedTrxForSettle.debt_amount)})
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Metode Pembayaran
                </label>
                <select
                  value={settleMethod}
                  onChange={e => setSettleMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-rose-500"
                >
                  <option value="cash">Cash (Tunai)</option>
                  <option value="qris">QRIS</option>
                  <option value="transfer">Transfer Bank</option>
                  <option value="ewallet">E-Wallet</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedTrxForSettle(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                >
                  Simpan Pelunasan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal: Hapus Satu Transaksi Piutang */}
      {trxToDeleteDebt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1.5">
              <h3 className="font-extrabold text-base text-slate-900">Hapus Transaksi Piutang?</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Hapus tagihan transaksi <b>{trxToDeleteDebt.invoice}</b> ({trxToDeleteDebt.customer_name}) sebesar <b>{formatRupiah(trxToDeleteDebt.debt_amount)}</b>? Saldo piutang pelanggan akan otomatis dikurangi.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setTrxToDeleteDebt(null)}
                className="flex-1 py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteDebtTransaction) {
                    onDeleteDebtTransaction(trxToDeleteDebt.id);
                  }
                  setTrxToDeleteDebt(null);
                }}
                className="flex-1 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
