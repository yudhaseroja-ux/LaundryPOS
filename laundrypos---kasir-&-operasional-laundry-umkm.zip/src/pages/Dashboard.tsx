import React from 'react';
import {
  Banknote,
  ShoppingBag,
  Clock,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  Plus,
  PackageCheck,
  UserCheck,
} from 'lucide-react';
import { Customer, Service, StoreSettings, Transaction, UserRole } from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo, formatDateTimeIndo, isToday } from '../utils/date';
import { StatusBadge } from '../components/StatusBadge';
import { PaymentStatusBadge } from '../components/PaymentStatusBadge';

interface Props {
  transactions: Transaction[];
  customers: Customer[];
  services: Service[];
  settings: StoreSettings;
  currentRole: UserRole;
  onOpenPOS: () => void;
  onViewReceipt: (trx: Transaction) => void;
  onNavigateTab: (tab: string) => void;
}

export const Dashboard: React.FC<Props> = ({
  transactions,
  customers,
  services,
  settings,
  currentRole,
  onOpenPOS,
  onViewReceipt,
  onNavigateTab,
}) => {
  // Calculations
  const todayTransactions = transactions.filter(t => isToday(t.date));
  const todayOmzet = todayTransactions.reduce((acc, curr) => acc + curr.total, 0);
  const todayPaid = todayTransactions.reduce((acc, curr) => acc + curr.paid_amount, 0);

  // Overall unpaid / piutang
  const totalPiutang = transactions.reduce((acc, curr) => acc + (curr.debt_amount || 0), 0);

  // Laundry in progress (not selesai)
  const inProgressList = transactions.filter(
    t => t.status !== 'selesai' && t.status !== 'siap_diambil'
  );
  const readyList = transactions.filter(t => t.status === 'siap_diambil');

  // Top services by count
  const serviceCountMap: Record<string, { name: string; count: number; omzet: number }> = {};
  transactions.forEach(t => {
    t.items.forEach(item => {
      if (!serviceCountMap[item.service_id]) {
        serviceCountMap[item.service_id] = { name: item.service_name, count: 0, omzet: 0 };
      }
      serviceCountMap[item.service_id].count += item.qty;
      serviceCountMap[item.service_id].omzet += item.subtotal;
    });
  });

  const topServices = Object.values(serviceCountMap)
    .sort((a, b) => b.count - a.count)
    .slice(0, 4);

  // Recent 5 transactions
  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-800 to-cyan-950 p-6 rounded-3xl text-white shadow-xl">
        <div>
          <span className="text-xs uppercase font-bold tracking-widest text-cyan-400">
            {settings.store_name} • Ringkasan Operasional
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1">
            Dashboard Laundry
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Pantau arus transaksi kasir, antrian cucian, dan status pembayaran secara realtime.
          </p>
        </div>

        {currentRole !== 'operator' && (
          <button
            onClick={onOpenPOS}
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-white font-bold text-sm rounded-2xl shadow-lg shadow-cyan-500/25 transition active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-5 h-5" />
            + Transaksi Baru (F2)
          </button>
        )}
      </div>

      {/* 5 Main Metric Cards as specified in PRD Section 3 */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5 sm:gap-4">
        {/* Omzet Hari Ini */}
        {currentRole !== 'operator' && (
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-cyan-300 transition">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Omzet Hari Ini
              </span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Banknote className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-extrabold text-slate-900">
              {formatRupiah(todayOmzet)}
            </div>
            <p className="text-[11px] text-emerald-600 font-medium mt-1">
              {todayTransactions.length} transaksi hari ini
            </p>
          </div>
        )}

        {/* Transaksi Hari Ini */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-cyan-300 transition">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Transaksi
            </span>
            <div className="w-8 h-8 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900">
            {todayTransactions.length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Total semua: {transactions.length} order
          </p>
        </div>

        {/* Belum Dibayar / Piutang */}
        {currentRole !== 'operator' && (
          <div
            onClick={() => onNavigateTab('piutang')}
            className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-rose-300 transition cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-rose-600 uppercase tracking-wider">
                Belum Dibayar
              </span>
              <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:scale-110 transition">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-extrabold text-rose-600">
              {formatRupiah(totalPiutang)}
            </div>
            <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 group-hover:text-rose-600">
              Lihat daftar piutang <ArrowRight className="w-3 h-3" />
            </p>
          </div>
        )}

        {/* Laundry Diproses */}
        <div
          onClick={() => onNavigateTab('laundry')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-cyan-300 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Laundry Diproses
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-110 transition">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-600">
            {inProgressList.length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 group-hover:text-amber-600">
            Antrian cuci & setrika <ArrowRight className="w-3 h-3" />
          </p>
        </div>

        {/* Siap Diambil */}
        <div
          onClick={() => onNavigateTab('laundry')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Siap Diambil
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition">
              <PackageCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-600">
            {readyList.length}
          </div>
          <p className="text-[11px] text-emerald-700 font-medium mt-1 flex items-center gap-1">
            Siap diserahkan <ArrowRight className="w-3 h-3" />
          </p>
        </div>
      </div>

      {/* Main Grid: Recent Transactions & Services breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions List (2 columns on lg) */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-extrabold text-lg text-slate-900">Transaksi Terbaru</h2>
              <p className="text-xs text-slate-500">Status pengerjaan dan pelunasan nota</p>
            </div>
            <button
              onClick={() => onNavigateTab('laundry')}
              className="text-xs font-bold text-cyan-600 hover:text-cyan-700 flex items-center gap-1"
            >
              Lihat Semua <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {recentTransactions.map(trx => (
              <div
                key={trx.id}
                onClick={() => onViewReceipt(trx)}
                className="p-4 rounded-2xl border border-slate-100 hover:border-cyan-300 hover:bg-slate-50/70 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer group"
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-mono font-bold text-xs group-hover:bg-cyan-100 group-hover:text-cyan-700 transition">
                    #{trx.invoice.slice(-4)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">
                        {trx.customer_name}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        {trx.invoice}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {trx.items.map(i => `${i.service_name} (${i.qty} ${i.unit})`).join(', ')}
                    </div>
                    {trx.rack_location && (
                      <span className="inline-block mt-1 text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                        Lokasi: {trx.rack_location}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 border-t sm:border-0 pt-2 sm:pt-0 border-slate-100">
                  <div className="text-sm font-black text-slate-900">
                    {formatRupiah(trx.total)}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <PaymentStatusBadge status={trx.payment_status} />
                    <StatusBadge status={trx.status} size="sm" />
                  </div>
                </div>
              </div>
            ))}

            {recentTransactions.length === 0 && (
              <div className="py-12 text-center text-slate-400 text-sm">
                Belum ada transaksi tercatat.
              </div>
            )}
          </div>
        </div>

        {/* Sidebar Widget: Top Services & Quick Stats */}
        <div className="space-y-6">
          {/* Top Services */}
          <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs">
            <h3 className="font-extrabold text-base text-slate-900 mb-1">Layanan Terlaris</h3>
            <p className="text-xs text-slate-500 mb-4">Volume cucian berdasarkan jenis layanan</p>

            <div className="space-y-3">
              {topServices.map((srv, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-800">{srv.name}</span>
                    <span className="font-bold text-slate-900">{srv.count} order</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-cyan-500 rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, (srv.count / (topServices[0]?.count || 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Customers Summary */}
          <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-extrabold text-base text-slate-900">Pelanggan Aktif</h3>
              <button
                onClick={() => onNavigateTab('customers')}
                className="text-xs font-bold text-cyan-600 hover:text-cyan-700"
              >
                Kelola
              </button>
            </div>

            <div className="space-y-2.5">
              {customers.slice(0, 4).map(c => (
                <div
                  key={c.id}
                  className="flex items-center justify-between text-xs p-2 rounded-xl bg-slate-50"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-cyan-100 text-cyan-700 font-bold flex items-center justify-center text-[11px]">
                      {c.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">{c.name}</div>
                      <div className="text-[10px] text-slate-500">{c.phone}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-slate-900">{c.total_transactions || 0} order</div>
                    {c.piutang_amount ? (
                      <span className="text-[10px] font-bold text-rose-600">
                        Piutang: {formatRupiah(c.piutang_amount)}
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-600 font-medium">Lunas</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
