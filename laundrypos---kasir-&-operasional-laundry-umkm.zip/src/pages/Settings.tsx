import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Sheet,
  Copy,
  Check,
  RefreshCw,
  Save,
  Download,
  Upload,
  AlertTriangle,
  Code2,
  Database,
  Store,
  Printer,
  Sparkles,
  Info,
  Users,
  Plus,
  Trash2,
  Key,
  Shield,
  UserCheck,
  Edit2,
  ArrowUpDown,
} from 'lucide-react';
import { StoreSettings, User, UserRole, Service, Customer, Transaction, Expense } from '../types';
import { GAS_SCRIPT_CODE } from '../services/gasScriptTemplate';
import { AppStorage } from '../services/storage';

interface Props {
  settings: StoreSettings;
  users?: User[];
  onSaveSettings: (settings: StoreSettings) => void;
  onSaveUser?: (user: User) => void;
  onDeleteUser?: (id: string) => void;
  onResetDemo: () => void;
  onDataReloaded?: (data: {
    services: Service[];
    customers: Customer[];
    users: User[];
    transactions: Transaction[];
    expenses: Expense[];
  }) => void;
}

export const Settings: React.FC<Props> = ({
  settings,
  users = [],
  onSaveSettings,
  onSaveUser,
  onDeleteUser,
  onResetDemo,
  onDataReloaded,
}) => {
  const [formData, setFormData] = useState<StoreSettings>({ ...settings });
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'users' | 'gas' | 'backup'>('profile');
  const [copiedCode, setCopiedCode] = useState(false);
  const [isTestingGas, setIsTestingGas] = useState(false);
  const [gasTestResult, setGasTestResult] = useState<{ success?: boolean; message?: string } | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync 2 Arah State
  const [isPushingGas, setIsPushingGas] = useState(false);
  const [isPullingGas, setIsPullingGas] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<{ success: boolean; message: string } | null>(null);

  // User Management State
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [userFormData, setUserFormData] = useState<Partial<User>>({
    name: '',
    username: '',
    password: '',
    role: 'kasir',
    status: 'active',
  });

  const handleCopyGasCode = async () => {
    try {
      await navigator.clipboard.writeText(GAS_SCRIPT_CODE);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleTestConnection = async () => {
    if (!formData.gas_api_url) {
      setGasTestResult({
        success: false,
        message: 'Masukkan URL Google Apps Script Web App terlebih dahulu.',
      });
      return;
    }

    setIsTestingGas(true);
    setGasTestResult(null);

    const res = await AppStorage.testGasConnection(formData.gas_api_url);
    setIsTestingGas(false);
    setGasTestResult(res);
  };

  // Push All to Google Sheet
  const handlePushAllToGas = async () => {
    setIsPushingGas(true);
    setSyncStatusMsg(null);
    const res = await AppStorage.pushAllToGas();
    setIsPushingGas(false);
    setSyncStatusMsg(res);
  };

  // Pull All from Google Sheet
  const handlePullAllFromGas = async () => {
    setIsPullingGas(true);
    setSyncStatusMsg(null);
    const res = await AppStorage.pullAllFromGas();
    setIsPullingGas(false);
    setSyncStatusMsg({ success: res.success, message: res.message });
    if (res.success && res.data && onDataReloaded) {
      onDataReloaded(res.data);
    }
  };

  const handleSubmitProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleOpenAddUser = () => {
    setEditingUser(null);
    setUserFormData({
      name: '',
      username: '',
      password: '',
      role: 'kasir',
      status: 'active',
    });
    setIsUserModalOpen(true);
  };

  const handleOpenEditUser = (user: User) => {
    setEditingUser(user);
    setUserFormData({ ...user });
    setIsUserModalOpen(true);
  };

  const handleSubmitUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userFormData.name || !userFormData.username) return;

    const userToSave: User = {
      id: editingUser ? editingUser.id : `usr-${Date.now().toString().slice(-4)}`,
      name: userFormData.name || '',
      username: userFormData.username || '',
      password: userFormData.password || 'password',
      role: (userFormData.role || 'kasir') as UserRole,
      status: (userFormData.status || 'active') as 'active' | 'inactive',
    };

    if (onSaveUser) {
      onSaveUser(userToSave);
    }
    setIsUserModalOpen(false);
  };

  const handleExportBackup = () => {
    const json = AppStorage.exportBackupJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_LaundryPOS_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      const content = event.target?.result as string;
      const success = AppStorage.importBackupJson(content);
      if (success) {
        alert('Data berhasil dipulihkan dari file backup! Halaman akan memuat ulang.');
        window.location.reload();
      } else {
        alert('File backup tidak valid atau format salah.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900">Pengaturan Sistem & Database</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola profil usaha, integrasi live Google Spreadsheet, user kasir & master data.
          </p>
        </div>

        {/* Sub-tab pills */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl text-xs font-bold">
          <button
            onClick={() => setActiveSubTab('profile')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'profile'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>Profil Toko & Nota</span>
          </button>

          <button
            onClick={() => setActiveSubTab('users')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'users'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-cyan-600" />
            <span>Kelola User & Kasir</span>
          </button>

          <button
            onClick={() => setActiveSubTab('gas')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'gas'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sheet className="w-3.5 h-3.5" />
            <span>Google Spreadsheet API</span>
          </button>

          <button
            onClick={() => setActiveSubTab('backup')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 ${
              activeSubTab === 'backup'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Backup & Data</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: Profil Toko & Nota */}
      {activeSubTab === 'profile' && (
        <form onSubmit={handleSubmitProfile} className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Store className="w-4 h-4 text-cyan-600" />
              Informasi Usaha Laundry
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nama Outlet / Usaha Laundry
                </label>
                <input
                  type="text"
                  required
                  value={formData.store_name}
                  onChange={e => setFormData({ ...formData, store_name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Slogan / Tagline
                </label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={e => setFormData({ ...formData, tagline: e.target.value })}
                  placeholder="Cth: Bersih, Rapi, Wangi & Cepat"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nomor WhatsApp / Telepon Kasir
                </label>
                <input
                  type="text"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Aroma Parfum Bawaan
                </label>
                <select
                  value={formData.default_perfume}
                  onChange={e => setFormData({ ...formData, default_perfume: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="Lavender">Lavender</option>
                  <option value="Snappy">Snappy</option>
                  <option value="Akasia">Akasia</option>
                  <option value="Downy Merah">Downy Merah</option>
                  <option value="Fresh Ocean">Fresh Ocean</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Alamat Lengkap Outlet
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Pesan Kaki Nota / Footer Struk (Syarat & Ketentuan)
                </label>
                <textarea
                  rows={3}
                  value={formData.receipt_footer}
                  onChange={e => setFormData({ ...formData, receipt_footer: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>
          </div>

          {/* Pengaturan Printer Thermal */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Printer className="w-4 h-4 text-cyan-600" />
              Format Printer Struk Thermal Kasir
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Lebar Kertas Printer Thermal
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paper_width: '58mm' })}
                    className={`py-3 px-4 rounded-xl text-xs font-bold border transition ${
                      formData.paper_width === '58mm'
                        ? 'border-cyan-600 bg-cyan-50 text-cyan-800'
                        : 'border-slate-200 bg-slate-50 text-slate-600'
                    }`}
                  >
                    58mm (Standar Portabel)
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paper_width: '80mm' })}
                    className={`py-3 px-4 rounded-xl text-xs font-bold border transition ${
                      formData.paper_width === '80mm'
                        ? 'border-cyan-600 bg-cyan-50 text-cyan-800'
                        : 'border-slate-200 bg-slate-50 text-slate-600'
                    }`}
                  >
                    80mm (Desktop POS)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Kode Negara WhatsApp
                </label>
                <input
                  type="text"
                  value={formData.whatsapp_country_code || '62'}
                  onChange={e => setFormData({ ...formData, whatsapp_country_code: e.target.value })}
                  placeholder="62"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3">
            {saveSuccess && (
              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                <Check className="w-4 h-4" /> Pengaturan profil berhasil disimpan!
              </span>
            )}
            <button
              type="submit"
              className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-sm rounded-xl shadow-xs transition flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Profil Usaha</span>
            </button>
          </div>
        </form>
      )}

      {/* SUB-TAB 2: Kelola User & Karyawan (Kasir / Operator / Owner) */}
      {activeSubTab === 'users' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-600" />
                Daftar Pengguna, Kasir & Operator
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Setiap perubahan user akan otomatis tersinkronkan ke tab <b>users</b> di Google Spreadsheet.
              </p>
            </div>

            <button
              type="button"
              onClick={handleOpenAddUser}
              className="px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah User Baru</span>
            </button>
          </div>

          {/* Table of Users */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase tracking-wider font-semibold">
                  <th className="p-3">Nama Lengkap</th>
                  <th className="p-3">Username Login</th>
                  <th className="p-3">Role / Hak Akses</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50/60 transition">
                    <td className="p-3 font-bold text-slate-800 flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-cyan-600 font-bold">
                        {u.name.charAt(0)}
                      </div>
                      <span>{u.name}</span>
                    </td>
                    <td className="p-3 font-mono text-slate-600">{u.username}</td>
                    <td className="p-3">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          u.role === 'owner'
                            ? 'bg-purple-100 text-purple-700 border border-purple-200'
                            : u.role === 'kasir'
                            ? 'bg-blue-100 text-blue-700 border border-blue-200'
                            : 'bg-amber-100 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        {u.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditUser(u)}
                          className="p-1.5 text-slate-500 hover:text-cyan-600 hover:bg-slate-100 rounded-lg transition"
                          title="Edit User"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {onDeleteUser && (
                          <button
                            type="button"
                            onClick={() => setUserToDelete(u)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="Hapus User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: Google Apps Script API (Live Spreadsheet Sync) */}
      {activeSubTab === 'gas' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
            <div>
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Sheet className="w-4 h-4 text-emerald-600" />
                Integrasi Google Spreadsheet Backend (Gratis Selamanya)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Sinkronisasikan <b>Layanan & Tarif</b>, <b>Data Pelanggan</b>, <b>User Kasir</b>, dan <b>Transaksi</b> ke Google Spreadsheet Anda.
              </p>
            </div>

            {/* TWO-WAY SYNC ACTION CARD */}
            <div className="p-4 bg-gradient-to-r from-emerald-50 via-teal-50 to-cyan-50 rounded-2xl border border-emerald-200/80 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-emerald-950 flex items-center gap-1.5">
                    <ArrowUpDown className="w-4 h-4 text-emerald-600" />
                    Sinkronisasi Data 2-Arah (Layanan, Pelanggan, User, Transaksi)
                  </h4>
                  <p className="text-xs text-emerald-800">
                    Sinkronkan master data lokal dengan Google Spreadsheet secara instan dengan 1 klik.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={handlePushAllToGas}
                  disabled={isPushingGas || isPullingGas || !formData.gas_api_url}
                  className="flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-xs transition"
                >
                  <Upload className={`w-4 h-4 ${isPushingGas ? 'animate-bounce' : ''}`} />
                  <span>{isPushingGas ? 'Mengirim ke Spreadsheet...' : 'Kirim Semua Data ke Google Sheet'}</span>
                </button>

                <button
                  type="button"
                  onClick={handlePullAllFromGas}
                  disabled={isPushingGas || isPullingGas || !formData.gas_api_url}
                  className="flex items-center justify-center gap-2 py-2.5 px-4 bg-cyan-600 hover:bg-cyan-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-xs transition"
                >
                  <Download className={`w-4 h-4 ${isPullingGas ? 'animate-bounce' : ''}`} />
                  <span>{isPullingGas ? 'Mengambil dari Spreadsheet...' : 'Tarik Data dari Google Sheet'}</span>
                </button>
              </div>

              {syncStatusMsg && (
                <div
                  className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                    syncStatusMsg.success
                      ? 'bg-white text-emerald-900 border border-emerald-300 shadow-xs'
                      : 'bg-white text-rose-800 border border-rose-300'
                  }`}
                >
                  {syncStatusMsg.success ? (
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{syncStatusMsg.message}</span>
                </div>
              )}

              {/* Sheet mapping breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 pt-2 border-t border-emerald-200/60 text-xs">
                <div className="p-2.5 bg-white/80 rounded-xl border border-emerald-100">
                  <div className="font-bold text-slate-800">Sheet: services</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    Layanan & tarif (kode, nama, harga per unit, durasi jam, status aktif).
                  </div>
                </div>
                <div className="p-2.5 bg-white/80 rounded-xl border border-emerald-100">
                  <div className="font-bold text-slate-800">Sheet: customers</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    Data pelanggan (nama, nomor WA, alamat, catatan, riwayat transaksi & piutang).
                  </div>
                </div>
                <div className="p-2.5 bg-white/80 rounded-xl border border-emerald-100">
                  <div className="font-bold text-slate-800">Sheet: users</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    User login kasir, operator, owner (nama, username, role, password).
                  </div>
                </div>
              </div>
            </div>

            {/* 4 Panduan Langkah Cepat */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-cyan-600">Langkah 1</div>
                <div className="font-bold text-slate-800">Buat Spreadsheet</div>
                <p className="text-slate-500 text-[11px]">
                  Buka sheet.new di browser Anda dan beri nama "Database LaundryPOS".
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-cyan-600">Langkah 2</div>
                <div className="font-bold text-slate-800">Buka Apps Script</div>
                <p className="text-slate-500 text-[11px]">
                  Di Google Sheet, klik menu <b>Ekstensi &gt; Apps Script</b>.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-cyan-600">Langkah 3</div>
                <div className="font-bold text-slate-800">Paste Code.gs</div>
                <p className="text-slate-500 text-[11px]">
                  Salin script di bawah, tempel di editor Apps Script, lalu klik Simpan.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-cyan-600">Langkah 4</div>
                <div className="font-bold text-slate-800">Deploy Web App</div>
                <p className="text-slate-500 text-[11px]">
                  Deploy &gt; New deployment &gt; Type: Web App &gt; Access: "Anyone". Salin URL Web App ke form di bawah.
                </p>
              </div>
            </div>

            {/* Input URL & Mode */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 pt-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Mode Sinkronisasi Backend
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const next = { ...formData, gas_sync_mode: 'local' as const };
                      setFormData(next);
                      onSaveSettings(next);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      formData.gas_sync_mode === 'local'
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-300'
                    }`}
                  >
                    Mode Lokal (Offline)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const next = { ...formData, gas_sync_mode: 'live' as const };
                      setFormData(next);
                      onSaveSettings(next);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      formData.gas_sync_mode === 'live'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-white text-slate-600 border border-slate-300'
                    }`}
                  >
                    Mode Live Google Spreadsheet (Aktif)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Google Apps Script Web App URL
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    value={formData.gas_api_url}
                    onChange={e => setFormData({ ...formData, gas_api_url: e.target.value })}
                    placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                    className="flex-1 px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                  <button
                    type="button"
                    disabled={isTestingGas || !formData.gas_api_url}
                    onClick={handleTestConnection}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-xs transition whitespace-nowrap flex items-center gap-1.5"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isTestingGas ? 'animate-spin' : ''}`} />
                    <span>{isTestingGas ? 'Menguji...' : 'Uji Koneksi'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onSaveSettings(formData);
                      setSaveSuccess(true);
                      setTimeout(() => setSaveSuccess(false), 2000);
                    }}
                    className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    Simpan URL
                  </button>
                </div>

                {gasTestResult && (
                  <div
                    className={`mt-2 p-3 rounded-xl text-xs font-medium flex items-center gap-2 ${
                      gasTestResult.success
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                        : 'bg-rose-50 text-rose-800 border border-rose-300'
                    }`}
                  >
                    {gasTestResult.success ? (
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                    <span>{gasTestResult.message}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Code Generator & Viewer */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-cyan-600" />
                  <span className="font-bold text-xs text-slate-800 uppercase tracking-wider">
                    Source Code Google Apps Script (Code.gs)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyGasCode}
                  className="px-3.5 py-1.5 bg-cyan-50 hover:bg-cyan-100 text-cyan-700 font-bold text-xs rounded-xl border border-cyan-200 transition flex items-center gap-1.5"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Tersalin ke Clipboard!' : 'Salin Seluruh Script'}</span>
                </button>
              </div>

              <div className="relative">
                <pre className="p-4 bg-slate-900 text-slate-200 rounded-2xl text-[11px] font-mono overflow-x-auto max-h-72 border border-slate-800 leading-relaxed select-all">
                  {GAS_SCRIPT_CODE}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: Backup & Data */}
      {activeSubTab === 'backup' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div>
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-600" />
              Cadangan & Pemulihan Data (Backup JSON & Reset)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Simpan cadangan database lokal ke komputer Anda atau pulihkan data kapan saja.
            </p>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Ekspor Backup */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-xs text-slate-800">Ekspor Cadangan (Download JSON)</h4>
                <p className="text-xs text-slate-500">
                  Unduh seluruh database (pengaturan, pelanggan, layanan, transaksi, pengeluaran) ke dalam 1 file JSON aman.
                </p>
                <button
                  onClick={handleExportBackup}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Backup JSON</span>
                </button>
              </div>

              {/* Impor Backup */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-xs text-slate-800">Impor Cadangan (Restore JSON)</h4>
                <p className="text-xs text-slate-500">
                  Pulihkan data dari file JSON yang pernah Anda unduh sebelumnya.
                </p>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Pilih File Backup JSON</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Reset Data Button */}
            <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 space-y-2 mt-4">
              <h4 className="font-bold text-xs text-rose-800 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                Opsi Reset Data (Demo / Kosongkan / Setelan Pabrik)
              </h4>
              <p className="text-xs text-rose-700">
                Pilih reset ke data demo PRD, kosongkan semua transaksi untuk usaha baru, atau reset setelan pabrik.
              </p>
              <button
                onClick={onResetDemo}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
              >
                Buka Opsi Reset Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* User Modal (Tambah / Edit User) */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-600" />
                {editingUser ? 'Edit Data User' : 'Tambah User Kasir / Karyawan'}
              </h3>
              <button
                onClick={() => setIsUserModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitUser} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  required
                  value={userFormData.name}
                  onChange={e => setUserFormData({ ...userFormData, name: e.target.value })}
                  placeholder="Cth: Siti Rahma"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Username Login
                </label>
                <input
                  type="text"
                  required
                  value={userFormData.username}
                  onChange={e => setUserFormData({ ...userFormData, username: e.target.value })}
                  placeholder="Cth: sitikasir"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Password Login
                </label>
                <input
                  type="text"
                  required
                  value={userFormData.password}
                  onChange={e => setUserFormData({ ...userFormData, password: e.target.value })}
                  placeholder="Password akun"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Role / Hak Akses
                  </label>
                  <select
                    value={userFormData.role}
                    onChange={e => setUserFormData({ ...userFormData, role: e.target.value as UserRole })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="owner">Owner (Semua Akses)</option>
                    <option value="kasir">Kasir (POS & Cucian)</option>
                    <option value="operator">Operator (Cuci/Setrika/Packing)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Status
                  </label>
                  <select
                    value={userFormData.status}
                    onChange={e => setUserFormData({ ...userFormData, status: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="active">Active (Aktif)</option>
                    <option value="inactive">Inactive (Non-aktif)</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
                {editingUser && onDeleteUser ? (
                  <button
                    type="button"
                    onClick={() => {
                      setUserToDelete(editingUser);
                      setIsUserModalOpen(false);
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-xl border border-rose-200 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus User</span>
                  </button>
                ) : <div />}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsUserModalOpen(false)}
                    className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
                  >
                    {editingUser ? 'Simpan Perubahan' : 'Tambah User'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete User Confirmation Modal */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-base text-slate-900">Hapus Data Pengguna?</h3>
              <p className="text-xs text-slate-500">
                Apakah Anda yakin ingin menghapus user <b>{userToDelete.name}</b> (@{userToDelete.username})? Data ini juga akan disinkronkan ke Google Spreadsheet.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="flex-1 py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteUser) {
                    onDeleteUser(userToDelete.id);
                  }
                  setUserToDelete(null);
                }}
                className="flex-1 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
