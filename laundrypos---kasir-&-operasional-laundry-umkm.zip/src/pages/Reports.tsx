import React, { useState } from 'react';
import {
  TrendingUp,
  Download,
  Printer,
  Calendar,
  Banknote,
  ShoppingBag,
  CreditCard,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  FileSpreadsheet,
} from 'lucide-react';
import { Expense, StoreSettings, Transaction } from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo, isToday } from '../utils/date';

interface Props {
  transactions: Transaction[];
  expenses: Expense[];
  settings: StoreSettings;
}

export const Reports: React.FC<Props> = ({ transactions, expenses, settings }) => {
  const [period, setPeriod] = useState<'today' | '7days' | 'month' | 'all'>('month');

  // Filter transactions and expenses based on period
  const now = new Date();
  const filteredTransactions = transactions.filter(t => {
    const tDate = new Date(t.date);
    if (period === 'today') return isToday(t.date);
    if (period === '7days') {
      const diff = (now.getTime() - tDate.getTime()) / (1000 * 3600 * 24);
      return diff <= 7;
    }
    if (period === 'month') {
      return (
        tDate.getMonth() === now.getMonth() && tDate.getFullYear() === now.getFullYear()
      );
    }
    return true;
  });

  const filteredExpenses = expenses.filter(e => {
    const eDate = new Date(e.date);
    if (period === 'today') return isToday(e.date);
    if (period === '7days') {
      const diff = (now.getTime() - eDate.getTime()) / (1000 * 3600 * 24);
      return diff <= 7;
    }
    if (period === 'month') {
      return (
        eDate.getMonth() === now.getMonth() && eDate.getFullYear() === now.getFullYear()
      );
    }
    return true;
  });

  // Financial aggregates
  const totalOmzet = filteredTransactions.reduce((acc, curr) => acc + curr.total, 0);
  const totalDiskon = filteredTransactions.reduce((acc, curr) => acc + curr.discount, 0);
  const totalPiutang = filteredTransactions.reduce((acc, curr) => acc + (curr.debt_amount || 0), 0);
  const totalCashIn = filteredTransactions.reduce((acc, curr) => acc + curr.paid_amount, 0);
  const totalExpense = filteredExpenses.reduce((acc, curr) => acc + curr.amount, 0);
  const netProfit = totalOmzet - totalExpense;

  // Breakdown by Service
  const serviceStats: Record<string, { name: string; count: number; omzet: number }> = {};
  filteredTransactions.forEach(t => {
    t.items.forEach(item => {
      if (!serviceStats[item.service_id]) {
        serviceStats[item.service_id] = { name: item.service_name, count: 0, omzet: 0 };
      }
      serviceStats[item.service_id].count += item.qty;
      serviceStats[item.service_id].omzet += item.subtotal;
    });
  });

  const topServices = Object.values(serviceStats).sort((a, b) => b.omzet - a.omzet);

  // Breakdown by Payment Method
  const paymentStats: Record<string, number> = {
    cash: 0,
    transfer: 0,
    qris: 0,
    ewallet: 0,
    piutang: 0,
  };

  filteredTransactions.forEach(t => {
    if (t.payment_methods && t.payment_methods.length > 0) {
      t.payment_methods.forEach(pm => {
        paymentStats[pm.method] = (paymentStats[pm.method] || 0) + pm.amount;
      });
    }
    if (t.debt_amount > 0) {
      paymentStats.piutang += t.debt_amount;
    }
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'No Invoice',
      'Tanggal',
      'Pelanggan',
      'Nomor HP',
      'Layanan',
      'Subtotal',
      'Diskon',
      'Total',
      'Dibayar',
      'Sisa Piutang',
      'Status Bayar',
      'Status Cucian',
    ];

    const rows = filteredTransactions.map(t => [
      t.invoice,
      t.date,
      `"${t.customer_name}"`,
      t.customer_phone,
      `"${t.items.map(i => `${i.service_name} (${i.qty} ${i.unit})`).join('; ')}"`,
      t.subtotal,
      t.discount,
      t.total,
      t.paid_amount,
      t.debt_amount,
      t.payment_status,
      t.status,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Laporan_LaundryPOS_${period}_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs no-print">
        <div>
          <h2 className="text-xl font-black text-slate-900">Laporan Usaha & Keuangan</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Analisis omzet, laba-rugi, efektivitas layanan, dan ringkasan pembayaran.
          </p>
        </div>

        {/* Filter and Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
            {[
              { id: 'today', label: 'Hari Ini' },
              { id: '7days', label: '7 Hari Terakhir' },
              { id: 'month', label: 'Bulan Ini' },
              { id: 'all', label: 'Semua Periode' },
            ].map(p => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id as any)}
                className={`px-3 py-1.5 rounded-lg transition ${
                  period === p.id
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Laporan</span>
          </button>
        </div>
      </div>

      {/* Main Financial KPI Grid (PRD Section 14) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Total Omzet
          </div>
          <div className="text-lg font-black text-slate-900 font-mono mt-1">
            {formatRupiah(totalOmzet)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            {filteredTransactions.length} transaksi
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Kas Masuk (Paid)
          </div>
          <div className="text-lg font-black text-emerald-600 font-mono mt-1">
            {formatRupiah(totalCashIn)}
          </div>
          <div className="text-[10px] text-emerald-700 mt-0.5">Uang riil diterima</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-rose-500">
            Piutang Tertahan
          </div>
          <div className="text-lg font-black text-rose-600 font-mono mt-1">
            {formatRupiah(totalPiutang)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Belum lunas</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Total Diskon
          </div>
          <div className="text-lg font-black text-amber-600 font-mono mt-1">
            {formatRupiah(totalDiskon)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Potongan promo</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Pengeluaran
          </div>
          <div className="text-lg font-black text-rose-600 font-mono mt-1">
            {formatRupiah(totalExpense)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Biaya operasional</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-600">
            Estimasi Laba Bersih
          </div>
          <div
            className={`text-lg font-black font-mono mt-1 ${
              netProfit >= 0 ? 'text-cyan-700' : 'text-rose-600'
            }`}
          >
            {formatRupiah(netProfit)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Omzet dikurang biaya</div>
        </div>
      </div>

      {/* Grid: Laporan Layanan & Laporan Pembayaran (PRD Section 14) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Laporan Layanan Terlaris */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          <div>
            <h3 className="font-extrabold text-base text-slate-900">
              Laporan Kinerja Layanan
            </h3>
            <p className="text-xs text-slate-500">Volume cucian dan kontribusi omzet</p>
          </div>

          <div className="space-y-3">
            {topServices.map((srv, idx) => (
              <div key={idx} className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-900">{srv.name}</span>
                  <div className="text-right font-mono">
                    <span className="font-extrabold text-slate-900">
                      {formatRupiah(srv.omzet)}
                    </span>
                    <span className="text-slate-400 text-[11px] ml-1.5">({srv.count} qty)</span>
                  </div>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-600 rounded-full"
                    style={{
                      width: `${Math.min(100, (srv.omzet / (totalOmzet || 1)) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            ))}

            {topServices.length === 0 && (
              <div className="py-12 text-center text-xs text-slate-400">
                Belum ada data layanan untuk periode ini.
              </div>
            )}
          </div>
        </div>

        {/* Laporan Metode Pembayaran */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          <div>
            <h3 className="font-extrabold text-base text-slate-900">
              Laporan Metode Pembayaran
            </h3>
            <p className="text-xs text-slate-500">Distribusi kas masuk dan piutang</p>
          </div>

          <div className="space-y-3">
            {[
              { label: 'Cash (Tunai)', amount: paymentStats.cash, color: 'bg-emerald-500' },
              { label: 'Transfer Bank', amount: paymentStats.transfer, color: 'bg-cyan-500' },
              { label: 'QRIS', amount: paymentStats.qris, color: 'bg-sky-500' },
              { label: 'E-Wallet', amount: paymentStats.ewallet, color: 'bg-indigo-500' },
              { label: 'Piutang Belum Bayar', amount: paymentStats.piutang, color: 'bg-rose-500' },
            ].map((pm, idx) => (
              <div key={idx} className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-800">{pm.label}</span>
                  <span className="font-mono font-bold text-slate-900">
                    {formatRupiah(pm.amount)}
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${pm.color} rounded-full`}
                    style={{
                      width: `${Math.min(100, (pm.amount / (totalOmzet || 1)) * 100)}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Print-only section for reporting */}
      <div className="printable-report hidden">
        <h2 style={{ fontSize: '18px', fontWeight: 'bold' }}>
          LAPORAN KEUANGAN & OPERASIONAL - {settings.store_name}
        </h2>
        <p style={{ fontSize: '12px', color: '#666' }}>Periode: {period.toUpperCase()}</p>
        <hr style={{ margin: '12px 0' }} />
        <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse' }}>
          <tbody>
            <tr>
              <td style={{ padding: '4px' }}>Total Omzet:</td>
              <td style={{ padding: '4px', fontWeight: 'bold' }}>{formatRupiah(totalOmzet)}</td>
            </tr>
            <tr>
              <td style={{ padding: '4px' }}>Kas Diterima:</td>
              <td style={{ padding: '4px' }}>{formatRupiah(totalCashIn)}</td>
            </tr>
            <tr>
              <td style={{ padding: '4px' }}>Sisa Piutang:</td>
              <td style={{ padding: '4px' }}>{formatRupiah(totalPiutang)}</td>
            </tr>
            <tr>
              <td style={{ padding: '4px' }}>Pengeluaran:</td>
              <td style={{ padding: '4px' }}>{formatRupiah(totalExpense)}</td>
            </tr>
            <tr>
              <td style={{ padding: '4px', fontWeight: 'bold' }}>Laba Bersih:</td>
              <td style={{ padding: '4px', fontWeight: 'bold' }}>{formatRupiah(netProfit)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
