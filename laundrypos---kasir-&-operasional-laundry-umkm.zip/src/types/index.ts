export type UserRole = 'owner' | 'kasir' | 'operator';

export interface User {
  id: string;
  name: string;
  username: string;
  password?: string;
  role: UserRole;
  status: 'active' | 'inactive';
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  phone: string;
  address?: string;
  gender?: 'L' | 'P' | 'other';
  notes?: string;
  created_at: string;
  updated_at?: string;
  total_transactions?: number;
  total_spent?: number;
  piutang_amount?: number;
}

export type ServiceUnit = 'Kg' | 'Pcs' | 'Meter' | 'Pasang' | 'Paket';

export interface Service {
  id: string;
  code: string;
  name: string;
  unit: ServiceUnit;
  price: number;
  status: 'active' | 'inactive';
  durationHours?: number;
  description?: string;
  category?: 'kiloan' | 'satuan' | 'express' | 'khusus';
}

export interface TransactionItem {
  id: string;
  service_id: string;
  service_code?: string;
  service_name: string;
  qty: number;
  unit: ServiceUnit;
  price: number;
  subtotal: number;
  notes?: string;
}

export type PaymentMethod = 'cash' | 'transfer' | 'qris' | 'ewallet' | 'piutang';

export interface SplitPaymentRecord {
  method: PaymentMethod;
  amount: number;
  reference?: string;
}

export type LaundryStatus = 
  | 'diterima'
  | 'dicuci'
  | 'dikeringkan'
  | 'disetrika'
  | 'dikemas'
  | 'siap_diambil'
  | 'selesai';

export interface LaundryStatusHistory {
  id: string;
  status: LaundryStatus;
  timestamp: string;
  user_name: string;
  notes?: string;
}

export interface Transaction {
  id: string;
  invoice: string; // e.g. LDR-20260930-0001
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  customer_address?: string;
  date: string;
  estimated_completion_date: string;
  items: TransactionItem[];
  subtotal: number;
  discount: number;
  total: number;
  paid_amount: number;
  debt_amount: number; // Sisa piutang
  change_amount: number; // Kembalian
  payment_status: 'lunas' | 'sebagian' | 'belum_lunas';
  payment_methods: SplitPaymentRecord[];
  status: LaundryStatus;
  status_history: LaundryStatusHistory[];
  rack_location?: string;
  perfume_choice?: string;
  notes?: string;
  created_by: string;
}

export type ExpenseCategory = 
  | 'Listrik'
  | 'Air'
  | 'Deterjen'
  | 'Pewangi'
  | 'Plastik'
  | 'Gaji'
  | 'Sewa'
  | 'Transport'
  | 'Maintenance'
  | 'Lainnya';

export interface Expense {
  id: string;
  date: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  payment_method: PaymentMethod;
  created_by?: string;
}

export interface StoreSettings {
  store_name: string;
  tagline: string;
  phone: string;
  address: string;
  receipt_footer: string;
  gas_api_url: string;
  gas_sync_mode: 'local' | 'live';
  paper_width: '58mm' | '80mm';
  default_perfume: string;
  whatsapp_country_code: string;
}
