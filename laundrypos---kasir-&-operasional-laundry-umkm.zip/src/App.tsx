import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Shirt,
  Users,
  CreditCard,
  Layers,
  TrendingDown,
  BarChart3,
  Settings as SettingsIcon,
  HelpCircle,
  Menu,
  X,
  Printer,
  Sparkles,
} from 'lucide-react';
import {
  Customer,
  Expense,
  LaundryStatus,
  PaymentMethod,
  Service,
  StoreSettings,
  Transaction,
  User as UserType,
  UserRole,
} from './types';
import { AppStorage } from './services/storage';
import { Header } from './components/Header';
import { Sidebar, NavItem } from './components/Sidebar';
import { ReceiptModal } from './components/ReceiptModal';
import { ShortcutsGuideModal } from './components/ShortcutsGuideModal';
import { ResetDataModal } from './components/ResetDataModal';

// Pages
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { POS } from './pages/POS';
import { LaundryWorkflow } from './pages/LaundryWorkflow';
import { Customers } from './pages/Customers';
import { Piutang } from './pages/Piutang';
import { Services } from './pages/Services';
import { Expenses } from './pages/Expenses';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';

export default function App() {
  // App Core State
  const [users, setUsers] = useState<UserType[]>([]);
  const [activeUser, setActiveUser] = useState<UserType | null>(null);
  const [settings, setSettings] = useState<StoreSettings>(AppStorage.getSettings());
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);

  // Navigation & Modals
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [receiptTrx, setReceiptTrx] = useState<Transaction | null>(null);

  // Initialize data on mount
  useEffect(() => {
    AppStorage.initFreshStart();
    const loadedUsers = AppStorage.getUsers();
    const loadedActiveUser = AppStorage.getActiveUser();
    const loadedSettings = AppStorage.getSettings();
    const loadedTrx = AppStorage.getTransactions();
    const loadedCust = AppStorage.getCustomers();
    const loadedSrv = AppStorage.getServices();
    const loadedExp = AppStorage.getExpenses();

    setUsers(loadedUsers);
    setActiveUser(loadedActiveUser);
    setSettings(loadedSettings);
    setTransactions(loadedTrx);
    setCustomers(loadedCust);
    setServices(loadedSrv);
    setExpenses(loadedExp);

    // If active user is operator, start at laundry workflow, otherwise dashboard
    if (loadedActiveUser && loadedActiveUser.role === 'operator') {
      setActiveTab('laundry');
    } else {
      setActiveTab('dashboard');
    }
  }, []);

  // Global Keyboard shortcuts (F2, F6, ESC)
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsShortcutsOpen(false);
        setReceiptTrx(null);
      } else if (e.key === 'F6') {
        e.preventDefault();
        if (transactions.length > 0) {
          setReceiptTrx(transactions[0]);
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [transactions]);

  // Handlers
  const handleLogout = () => {
    AppStorage.logout();
    setActiveUser(null);
  };

  const handleLoginSuccess = (user: UserType) => {
    setActiveUser(user);
    if (user.role === 'operator') {
      setActiveTab('laundry');
    } else {
      setActiveTab('dashboard');
    }
  };

  if (!activeUser) {
    return (
      <Login
        onLoginSuccess={handleLoginSuccess}
        storeName={settings.store_name}
        tagline={settings.tagline}
      />
    );
  }

  // Handlers
  const handleSwitchUser = (user: UserType) => {
    setActiveUser(user);
    AppStorage.setActiveUser(user);
    if (user.role === 'operator' && (activeTab === 'pos' || activeTab === 'reports' || activeTab === 'settings' || activeTab === 'expenses')) {
      setActiveTab('laundry');
    }
  };

  const handleSaveTransaction = (newTrx: Transaction) => {
    const { transactions: nextTrx, customers: nextCust } = AppStorage.saveTransaction(newTrx);
    setTransactions([...nextTrx]);
    setCustomers([...nextCust]);
  };

  const handleUpdateStatus = (transactionId: string, newStatus: LaundryStatus, notes?: string) => {
    const updated = AppStorage.updateLaundryStatus(
      transactionId,
      newStatus,
      activeUser.name,
      notes
    );
    setTransactions([...updated]);
  };

  const handleSettleDebt = (transactionId: string, amount: number, method: PaymentMethod) => {
    const { transactions: nextTrx, customers: nextCust } = AppStorage.settleDebt(
      transactionId,
      amount,
      method
    );
    setTransactions([...nextTrx]);
    setCustomers([...nextCust]);
    const settledTrx = nextTrx.find(t => t.id === transactionId);
    if (settledTrx) {
      setReceiptTrx(settledTrx);
    }
  };

  const handleClearAllDebts = () => {
    const res = AppStorage.clearDebtTransactions();
    setTransactions([...res.transactions]);
    setCustomers([...res.customers]);
  };

  const handleDeleteDebtTransaction = (transactionId: string) => {
    const res = AppStorage.deleteDebtTransaction(transactionId);
    setTransactions([...res.transactions]);
    setCustomers([...res.customers]);
  };

  const handleSaveCustomer = (customer: Customer) => {
    const next = AppStorage.saveCustomer(customer);
    setCustomers([...next]);
  };

  const handleDeleteCustomer = (id: string) => {
    const next = AppStorage.deleteCustomer(id);
    setCustomers([...next]);
  };

  const handleSaveService = (service: Service) => {
    const next = AppStorage.saveService(service);
    setServices([...next]);
  };

  const handleSaveExpense = (expense: Expense) => {
    const next = AppStorage.saveExpense(expense);
    setExpenses([...next]);
  };

  const handleDeleteExpense = (id: string) => {
    const next = AppStorage.deleteExpense(id);
    setExpenses([...next]);
  };

  const handleSaveSettings = (newSettings: StoreSettings) => {
    AppStorage.saveSettings(newSettings);
    setSettings(newSettings);
  };

  const handleSaveUser = (user: UserType) => {
    const next = AppStorage.saveUser(user);
    setUsers([...next]);
    if (activeUser && activeUser.id === user.id) {
      setActiveUser(user);
    }
  };

  const handleDeleteUser = (id: string) => {
    const next = AppStorage.deleteUser(id);
    setUsers([...next]);
  };

  const handleResetDemo = () => {
    AppStorage.resetToDemo();
    setUsers(AppStorage.getUsers());
    const active = AppStorage.getActiveUser();
    setActiveUser(active);
    setSettings(AppStorage.getSettings());
    setTransactions(AppStorage.getTransactions());
    setCustomers(AppStorage.getCustomers());
    setServices(AppStorage.getServices());
    setExpenses(AppStorage.getExpenses());
    setActiveTab('dashboard');
  };

  const handleClearTransactions = () => {
    AppStorage.clearTransactionsAndDebts();
    setTransactions([]);
    setExpenses([]);
    setCustomers(AppStorage.getCustomers());
    setActiveTab('dashboard');
  };

  const handleFactoryReset = () => {
    AppStorage.factoryReset();
    setUsers(AppStorage.getUsers());
    setSettings(AppStorage.getSettings());
    setTransactions([]);
    setCustomers([]);
    setServices(AppStorage.getServices());
    setExpenses([]);
    setActiveUser(null);
  };

  // Role permissions filter for navigation
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['owner', 'kasir'] },
    { id: 'pos', label: 'Kasir POS (F2)', icon: ShoppingCart, roles: ['owner', 'kasir'] },
    { id: 'laundry', label: 'Operasional Cucian', icon: Shirt, roles: ['owner', 'kasir', 'operator'] },
    { id: 'customers', label: 'Pelanggan', icon: Users, roles: ['owner', 'kasir'] },
    { id: 'piutang', label: 'Piutang', icon: CreditCard, roles: ['owner', 'kasir'] },
    { id: 'services', label: 'Layanan & Tarif', icon: Layers, roles: ['owner'] },
    { id: 'expenses', label: 'Pengeluaran', icon: TrendingDown, roles: ['owner'] },
    { id: 'reports', label: 'Laporan Usaha', icon: BarChart3, roles: ['owner'] },
    { id: 'settings', label: 'Google Sheets & Setting', icon: SettingsIcon, roles: ['owner'] },
  ];

  const allowedNavItems = navItems.filter(item => item.roles.includes(activeUser.role));

  const inProgressLaundryCount = transactions.filter(
    t => t.status !== 'selesai' && t.status !== 'siap_diambil'
  ).length;
  const unpaidTrxCount = transactions.filter(t => (t.debt_amount || 0) > 0).length;

  return (
    <div className="min-h-screen bg-slate-100 flex text-slate-800 antialiased">
      {/* Left Sidebar Component */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(prev => !prev)}
        navItems={allowedNavItems}
        activeTab={activeTab}
        onSelectTab={tabId => setActiveTab(tabId)}
        activeUser={activeUser}
        users={users}
        onSwitchUser={handleSwitchUser}
        onLogout={handleLogout}
        storeName={settings.store_name}
        tagline={settings.tagline}
        inProgressCount={inProgressLaundryCount}
        unpaidCount={unpaidTrxCount}
      />

      {/* Main Container positioned to the right of Left Sidebar */}
      <div
        className={`flex-1 flex flex-col min-h-screen transition-all duration-300 w-full overflow-x-hidden ${
          isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72'
        }`}
      >
        {/* Top Header */}
        <Header
          settings={settings}
          activeUser={activeUser}
          users={users}
          onSwitchUser={handleSwitchUser}
          onOpenShortcuts={() => setIsShortcutsOpen(true)}
          activeTab={activeTab}
          isSidebarOpen={isSidebarOpen}
          onToggleSidebar={() => {
            if (window.innerWidth >= 1024) {
              setIsSidebarCollapsed(prev => !prev);
            } else {
              setIsSidebarOpen(prev => !prev);
            }
          }}
          onLogout={handleLogout}
        />

        {/* Content Wrapper */}
        <div className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 flex flex-col gap-6">
          {/* Quick Breadcrumb and Active View Header */}
          <div className="flex items-center justify-between no-print">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <span className="text-slate-400">LaundryPOS</span>
              <span>/</span>
              <span className="text-slate-900 font-bold uppercase tracking-wider">
                {allowedNavItems.find(n => n.id === activeTab)?.label || activeTab}
              </span>
            </div>

            {/* Quick shortcut indicator */}
            <div className="hidden sm:flex items-center gap-2">
              {activeTab !== 'dashboard' && (
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="text-xs font-bold text-slate-600 hover:text-cyan-600 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs hover:border-slate-300 transition"
                >
                  ← Kembali ke Dashboard
                </button>
              )}
              {activeTab !== 'pos' && activeUser.role !== 'operator' && (
                <button
                  onClick={() => setActiveTab('pos')}
                  className="text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-500 px-3.5 py-1.5 rounded-xl shadow-xs transition"
                >
                  + Kasir POS (F2)
                </button>
              )}
            </div>
          </div>

          {/* Main Content Area */}
          <main className="flex-1 pb-16">
            {activeTab === 'dashboard' && (
              <Dashboard
                transactions={transactions}
                customers={customers}
                services={services}
                settings={settings}
                currentRole={activeUser.role}
                onOpenPOS={() => setActiveTab('pos')}
                onViewReceipt={trx => setReceiptTrx(trx)}
                onNavigateTab={tab => setActiveTab(tab)}
              />
            )}

            {activeTab === 'pos' && (
              <POS
                services={services}
                customers={customers}
                settings={settings}
                activeUser={activeUser}
                onSaveTransaction={handleSaveTransaction}
                onSaveCustomer={handleSaveCustomer}
                onShowReceipt={trx => setReceiptTrx(trx)}
              />
            )}

            {activeTab === 'laundry' && (
              <LaundryWorkflow
                transactions={transactions}
                settings={settings}
                activeUser={activeUser}
                currentRole={activeUser.role}
                onUpdateStatus={handleUpdateStatus}
                onViewReceipt={trx => setReceiptTrx(trx)}
              />
            )}

            {activeTab === 'customers' && (
              <Customers
                customers={customers}
                transactions={transactions}
                settings={settings}
                onSaveCustomer={handleSaveCustomer}
                onDeleteCustomer={handleDeleteCustomer}
                onViewReceipt={trx => setReceiptTrx(trx)}
              />
            )}

            {activeTab === 'piutang' && (
              <Piutang
                transactions={transactions}
                customers={customers}
                settings={settings}
                onSettleDebt={handleSettleDebt}
                onDeleteDebtTransaction={handleDeleteDebtTransaction}
                onViewReceipt={trx => setReceiptTrx(trx)}
              />
            )}

            {activeTab === 'services' && (
              <Services services={services} onSaveService={handleSaveService} />
            )}

            {activeTab === 'expenses' && (
              <Expenses
                expenses={expenses}
                activeUser={activeUser}
                onSaveExpense={handleSaveExpense}
                onDeleteExpense={handleDeleteExpense}
              />
            )}

            {activeTab === 'reports' && (
              <Reports
                transactions={transactions}
                expenses={expenses}
                settings={settings}
              />
            )}

            {activeTab === 'settings' && (
              <Settings
                settings={settings}
                users={users}
                onSaveSettings={handleSaveSettings}
                onSaveUser={handleSaveUser}
                onDeleteUser={handleDeleteUser}
                onResetDemo={() => setIsResetModalOpen(true)}
                onDataReloaded={data => {
                  setServices([...data.services]);
                  setCustomers([...data.customers]);
                  setUsers([...data.users]);
                  setTransactions([...data.transactions]);
                  setExpenses([...data.expenses]);
                }}
              />
            )}
          </main>
        </div>
      </div>

      {/* Reset Data Options Modal */}
      <ResetDataModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onResetDemo={handleResetDemo}
        onClearTransactions={handleClearTransactions}
        onFactoryReset={handleFactoryReset}
      />

      {/* Thermal Receipt & WhatsApp Modal */}
      <ReceiptModal
        isOpen={Boolean(receiptTrx)}
        transaction={receiptTrx}
        settings={settings}
        onClose={() => setReceiptTrx(null)}
      />

      {/* POS Shortcuts Guide Modal */}
      <ShortcutsGuideModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />
    </div>
  );
}
