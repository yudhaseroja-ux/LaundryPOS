import React from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  ShoppingBag,
  Clock,
  Layers,
  Phone,
  ShieldCheck,
  LucideIcon,
  Waves,
  LogOut,
  User as UserIcon,
} from 'lucide-react';
import { UserRole, User as UserType } from '../types';

export interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  roles: string[];
  badge?: string | number;
}

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  navItems: NavItem[];
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  activeUser: UserType;
  users: UserType[];
  onSwitchUser: (user: UserType) => void;
  onLogout: () => void;
  storeName: string;
  tagline?: string;
  inProgressCount?: number;
  unpaidCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  isCollapsed,
  onToggleCollapse,
  navItems,
  activeTab,
  onSelectTab,
  activeUser,
  users,
  onSwitchUser,
  onLogout,
  storeName,
  tagline,
  inProgressCount = 0,
  unpaidCount = 0,
}) => {
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-40 lg:hidden transition-opacity"
        />
      )}

      {/* Left Sidebar Container */}
      <aside
        className={`fixed top-0 left-0 bottom-0 z-50 bg-slate-900 border-r border-slate-800 text-slate-100 flex flex-col transition-all duration-300 shadow-2xl no-print ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } ${isCollapsed ? 'lg:w-20' : 'lg:w-72 w-80'}`}
      >
        {/* Sidebar Header / Brand */}
        <div className="h-16 px-4 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-sky-400 text-white flex items-center justify-center shadow-lg shadow-cyan-500/20 shrink-0">
              <Waves className="w-5 h-5" />
            </div>
            {!isCollapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm tracking-tight text-white truncate">
                    {storeName}
                  </span>
                  <span className="text-[9px] uppercase font-bold tracking-widest px-1 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    POS
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 truncate">
                  {tagline || 'Laundry Management'}
                </p>
              </div>
            )}
          </div>

          {/* Close button for Mobile / Collapse button for Desktop */}
          <div className="flex items-center">
            {/* Mobile close */}
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              aria-label="Tutup Menu"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Desktop collapse toggle */}
            <button
              onClick={onToggleCollapse}
              className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title={isCollapsed ? 'Perluas Sidebar' : 'Ciutkan Sidebar'}
            >
              {isCollapsed ? (
                <ChevronRight className="w-4 h-4 text-cyan-400" />
              ) : (
                <ChevronLeft className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {/* Quick New Transaction Action button inside Sidebar */}
        {activeUser.role !== 'operator' && (
          <div className="p-3 border-b border-slate-800 shrink-0">
            <button
              onClick={() => {
                onSelectTab('pos');
                onClose();
              }}
              title="Buat Transaksi Kasir Baru (F2)"
              className={`w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-white font-bold rounded-xl shadow-md shadow-cyan-900/30 transition transform active:scale-98 ${
                isCollapsed ? 'px-0' : ''
              }`}
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              {!isCollapsed && (
                <span className="text-xs tracking-wide">
                  + Transaksi Baru <span className="text-cyan-200 text-[10px]">(F2)</span>
                </span>
              )}
            </button>
          </div>
        )}

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-1.5 custom-scrollbar">
          {!isCollapsed && (
            <div className="px-3 pb-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Menu Navigasi
            </div>
          )}

          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            // Extra badges
            let badgeValue = item.badge;
            let badgeColor = 'bg-slate-800 text-slate-300';
            if (item.id === 'laundry' && inProgressCount > 0) {
              badgeValue = `${inProgressCount} antri`;
              badgeColor = 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30';
            } else if (item.id === 'piutang' && unpaidCount > 0) {
              badgeValue = `${unpaidCount} tagihan`;
              badgeColor = 'bg-amber-500/20 text-amber-300 border border-amber-500/30';
            }

            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  onClose();
                }}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition group relative ${
                  isActive
                    ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/20 font-bold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                } ${isCollapsed ? 'justify-center' : 'justify-between'}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Icon
                    className={`w-5 h-5 shrink-0 transition ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-cyan-400'
                    }`}
                  />
                  {!isCollapsed && <span className="truncate">{item.label}</span>}
                </div>

                {/* Badge when expanded */}
                {!isCollapsed && badgeValue && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${badgeColor}`}
                  >
                    {badgeValue}
                  </span>
                )}

                {/* Collapsed dot indicator for badge */}
                {isCollapsed && badgeValue && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-slate-900" />
                )}
              </button>
            );
          })}
        </div>

        {/* Sidebar Footer: Active User & Logout */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/40 shrink-0">
          {!isCollapsed ? (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400 shrink-0">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">{activeUser.name}</p>
                    <div className="flex items-center gap-1.5">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                        {activeUser.role}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Logout Button */}
                <button
                  onClick={onLogout}
                  title="Keluar / Logout"
                  className="p-1.5 rounded-lg text-rose-400 hover:text-white hover:bg-rose-600/80 transition"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>

              {/* Role Switcher Selector */}
              {users.length > 1 && (
                <div className="pt-1">
                  <label className="text-[10px] text-slate-400 font-medium block mb-1">
                    Ganti Akun Cepat:
                  </label>
                  <select
                    value={activeUser.id}
                    onChange={e => {
                      const found = users.find(u => u.id === e.target.value);
                      if (found) onSwitchUser(found);
                    }}
                    className="w-full bg-slate-800 text-xs font-medium text-slate-200 rounded-lg px-2.5 py-1.5 border border-slate-700 focus:outline-none focus:ring-1 focus:ring-cyan-500 cursor-pointer"
                  >
                    {users.map(u => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.role.toUpperCase()})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 py-1">
              <div
                title={`${activeUser.name} (${activeUser.role.toUpperCase()})`}
                className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400"
              >
                <UserIcon className="w-4 h-4" />
              </div>
              <button
                onClick={onLogout}
                title="Keluar / Logout"
                className="w-9 h-9 rounded-xl bg-rose-950/40 hover:bg-rose-600 text-rose-400 hover:text-white flex items-center justify-center border border-rose-800/40 transition"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
