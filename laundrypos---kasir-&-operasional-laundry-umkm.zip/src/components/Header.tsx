import React, { useState, useEffect } from 'react';
import {
  Waves,
  ShieldCheck,
  User,
  Keyboard,
  RefreshCw,
  Clock,
  Sparkles,
  Sheet,
  CheckCircle,
  Menu,
  X,
  LogOut,
} from 'lucide-react';
import { StoreSettings, User as UserType, UserRole } from '../types';

interface Props {
  settings: StoreSettings;
  activeUser: UserType;
  users: UserType[];
  onSwitchUser: (user: UserType) => void;
  onOpenShortcuts: () => void;
  activeTab: string;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  onLogout: () => void;
}

export const Header: React.FC<Props> = ({
  settings,
  activeUser,
  users,
  onSwitchUser,
  onOpenShortcuts,
  isSidebarOpen,
  onToggleSidebar,
  onLogout,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md no-print">
      <div className="w-full px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Sidebar Toggle + Brand */}
        <div className="flex items-center gap-3">
          {/* Left Sidebar Menu Toggle Button */}
          <button
            onClick={onToggleSidebar}
            title={isSidebarOpen ? 'Tutup Menu Samping' : 'Buka Menu Samping'}
            className="flex items-center justify-center w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition active:scale-95"
          >
            {isSidebarOpen ? <X className="w-5 h-5 text-cyan-400" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-sky-400 text-white flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Waves className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-white">
                  {settings.store_name}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  POS
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block truncate max-w-xs">
                {settings.tagline}
              </p>
            </div>
          </div>
        </div>

        {/* Right tools: Clock, GAS Status, Shortcut Pill, Role Switcher, Logout */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Clock */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-400 font-mono bg-slate-800/80 px-2.5 py-1.5 rounded-lg border border-slate-700">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{timeStr}</span>
          </div>

          {/* GAS Sync status */}
          <div
            className={`hidden md:flex items-center gap-2 text-xs px-2.5 py-1.5 rounded-lg border font-medium transition ${
              settings.gas_sync_mode === 'live' && settings.gas_api_url
                ? 'bg-emerald-950/70 text-emerald-300 border-emerald-700/80 shadow-xs'
                : 'bg-slate-800 text-slate-300 border-slate-700'
            }`}
          >
            {settings.gas_sync_mode === 'live' && settings.gas_api_url && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            )}
            <Sheet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="font-semibold">
              {settings.gas_sync_mode === 'live' && settings.gas_api_url
                ? 'Google Sheets API Aktif'
                : 'Mode Standalone'}
            </span>
          </div>

          {/* Shortcut guide trigger */}
          <button
            onClick={onOpenShortcuts}
            title="Lihat Shortcut Keyboard Kasir (F2-F6)"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700 transition"
          >
            <Keyboard className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Shortcuts</span>
          </button>

          {/* User Role Switcher */}
          <div className="flex items-center gap-2 bg-slate-800/90 pl-2.5 pr-1 py-1 rounded-xl border border-slate-700">
            <div className="flex items-center gap-1.5 text-xs">
              <User className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden xl:inline text-slate-300 font-medium">Role:</span>
            </div>
            <select
              value={activeUser.id}
              onChange={e => {
                const found = users.find(u => u.id === e.target.value);
                if (found) onSwitchUser(found);
              }}
              className="bg-slate-900 text-xs font-semibold text-cyan-300 rounded-lg px-2 py-1 border border-slate-700 focus:outline-none focus:ring-1 focus:ring-cyan-500 cursor-pointer"
            >
              {users.map(u => (
                <option key={u.id} value={u.id}>
                  {u.name} [{u.role.toUpperCase()}]
                </option>
              ))}
            </select>
          </div>

          {/* Logout Button */}
          <button
            onClick={onLogout}
            title="Keluar dari Akun"
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-xl text-xs font-bold border border-rose-500/30 transition active:scale-95"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Keluar</span>
          </button>
        </div>
      </div>
    </header>
  );
};
