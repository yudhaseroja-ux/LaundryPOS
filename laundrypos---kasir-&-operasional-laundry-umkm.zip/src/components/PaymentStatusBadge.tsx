import React from 'react';

interface Props {
  status: 'lunas' | 'sebagian' | 'belum_lunas';
  size?: 'sm' | 'md';
}

export const PaymentStatusBadge: React.FC<Props> = ({ status, size = 'sm' }) => {
  const styles = {
    lunas: 'bg-emerald-50 text-emerald-700 border-emerald-300',
    sebagian: 'bg-amber-50 text-amber-700 border-amber-300',
    belum_lunas: 'bg-rose-50 text-rose-700 border-rose-300 font-semibold',
  };

  const labels = {
    lunas: 'LUNAS',
    sebagian: 'SEBAGIAN',
    belum_lunas: 'BELUM LUNAS',
  };

  const sizeClass = size === 'sm' ? 'text-[11px] px-2 py-0.5' : 'text-xs px-2.5 py-1';

  return (
    <span
      className={`inline-flex items-center rounded border font-mono tracking-wider font-semibold ${styles[status]} ${sizeClass}`}
    >
      {labels[status]}
    </span>
  );
};
