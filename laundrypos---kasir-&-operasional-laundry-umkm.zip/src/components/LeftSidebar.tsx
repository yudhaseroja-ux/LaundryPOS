import React from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Sparkles,
  ShoppingBag,
  Clock,
  Layers,
  Phone,
  ShieldCheck,
  LucideIcon,
  Waves,
} from 'lucide-react';
import { UserRole } from '../types';

export interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  roles: string[];
  badge?: string | number;
}

interface LeftSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  navItems: NavItem[];
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  activeRole: UserRole;
  storeName: string;
  inProgressCount?: number;
  unpaidCount?: number;
  userName?: string;
  onLogout: () => void;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  isOpen,
  onClose,
  isCollapsed,
  onToggleCollapse,
  navItems,
  activeTab,
  onSelectTab,
  activeRole,
  storeName,
  inProgressCount = 0,
  unpaidCount = 0,
  userName = 'User',
  onLogout,
}) => {
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs z-40 lg:hidden transition-opacity"
        />
      )}

      {/* Left Sidebar Container */}
      <aside
        className={`fixed top-16 left-0 bottom-0 z-40 bg-slate-900 border-r border-slate-800 text-slate-100 flex flex-col transition-all duration-300 shadow-xl no-print ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } ${isCollapsed ? 'lg:w-20' : 'lg:w-64 w-72'}`}
      >
        {/* Sidebar Header / Brand info in sidebar */}
        <div className="h-14 px-4 border-b border-slate-800 flex items-center justify-between">
          {!isCollapsed ? (
            <div className="flex items-center gap-2 overflow-hidden">
              <span className="text-xs uppercase font-extrabold tracking-widest text-cyan-400 truncate">
                Menu Utama
              </span>
              <span className="text-[10px] bg-slate-800 text-cyan-300 border border-slate-700 px-2 py-0.5 rounded-full font-mono uppercase">
                {activeRole}
              </span>
            </div>
          ) : (
            <div className="w-full flex justify-center">
              <span className="text-[10px] bg-slate-800 text-cyan-300 px-1 py-0.5 rounded font-mono uppercase">
                {activeRole.slice(0, 3)}
              </span>
            </div>
          )}

          <div className="flex items-center gap-1">
            {/* Collapse toggle (desktop only) */}
            <button
              onClick={onToggleCollapse}
              title={isCollapsed ? 'Perluas Sidebar' : 'Ciutkan Sidebar'}
              className="hidden lg:flex items-center justify-center w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              {isCollapsed ? (
                <ChevronRight className="w-4 h-4 text-cyan-400" />
              ) : (
                <ChevronLeft className="w-4 h-4" />
              )}
            </button>

            {/* Mobile close button */}
            <button
              onClick={onClose}
              className="lg:hidden flex items-center justify-center w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Items List */}
        <div className="flex-1 py-4 px-3 space-y-1.5 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  if (window.innerWidth < 1024) onClose();
                }}
                title={isCollapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition group relative ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-600 to-sky-600 text-white shadow-lg shadow-cyan-600/25 ring-1 ring-cyan-400/40'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/80'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-cyan-400'
                  }`}
                />

                {!isCollapsed && (
                  <span className="truncate flex-1 text-left">{item.label}</span>
                )}

                {/* Realtime Badges */}
                {!isCollapsed && item.id === 'laundry' && inProgressCount > 0 && (
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                      isActive
                        ? 'bg-white text-cyan-800'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {inProgressCount}
                  </span>
                )}

                {!isCollapsed && item.id === 'piutang' && unpaidCount > 0 && (
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                      isActive
                        ? 'bg-white text-rose-800'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {unpaidCount}
                  </span>
                )}

                {/* Collapsed active indicator bar */}
                {isCollapsed && isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-cyan-400 rounded-r-full" />
                )}
              </button>
            );
          })}
        </div>

        {/* Sidebar Footer with user info & Logout Button */}
        <div className="p-3 border-t border-slate-800 space-y-2">
          {!isCollapsed && (
            <div className="px-2 py-1.5 flex items-center justify-between text-xs">
              <div className="truncate">
                <div className="font-bold text-slate-200 truncate">{userName}</div>
                <div className="text-[10px] text-cyan-400 uppercase font-mono">
                  Role: {activeRole}
                </div>
              </div>
            </div>
          )}

          <button
            onClick={onLogout}
            title="Keluar / Logout Akun"
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-400 hover:text-white hover:bg-rose-600/80 transition active:scale-95 ${
              isCollapsed ? 'justify-center' : ''
            }`}
          >
            <LogOut className="w-4 h-4 shrink-0" />
            {!isCollapsed && <span>Keluar (Logout)</span>}
          </button>
        </div>
      </aside>
    </>
  );
};
