import React from 'react';
import { LaundryStatus } from '../types';

export const STATUS_LABELS: Record<LaundryStatus, string> = {
  diterima: 'Diterima',
  dicuci: 'Dicuci',
  dikeringkan: 'Dikeringkan',
  disetrika: 'Disetrika',
  dikemas: 'Dikemas',
  siap_diambil: 'Siap Diambil',
  selesai: 'Selesai',
};

export const STATUS_ORDER: LaundryStatus[] = [
  'diterima',
  'dicuci',
  'dikeringkan',
  'disetrika',
  'dikemas',
  'siap_diambil',
  'selesai',
];

interface StatusBadgeProps {
  status: LaundryStatus;
  size?: 'sm' | 'md' | 'lg';
  showDot?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  size = 'md',
  showDot = true,
}) => {
  const getStyle = () => {
    switch (status) {
      case 'diterima':
        return 'bg-slate-100 text-slate-700 border-slate-300';
      case 'dicuci':
        return 'bg-cyan-50 text-cyan-700 border-cyan-300';
      case 'dikeringkan':
        return 'bg-amber-50 text-amber-700 border-amber-300';
      case 'disetrika':
        return 'bg-purple-50 text-purple-700 border-purple-300';
      case 'dikemas':
        return 'bg-indigo-50 text-indigo-700 border-indigo-300';
      case 'siap_diambil':
        return 'bg-emerald-50 text-emerald-700 border-emerald-400 font-semibold ring-1 ring-emerald-400/30';
      case 'selesai':
        return 'bg-gray-100 text-gray-500 border-gray-200';
      default:
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const getDotColor = () => {
    switch (status) {
      case 'diterima': return 'bg-slate-400';
      case 'dicuci': return 'bg-cyan-500 animate-pulse';
      case 'dikeringkan': return 'bg-amber-500 animate-pulse';
      case 'disetrika': return 'bg-purple-500';
      case 'dikemas': return 'bg-indigo-500';
      case 'siap_diambil': return 'bg-emerald-500 animate-bounce';
      case 'selesai': return 'bg-gray-400';
    }
  };

  const sizeClass = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
    lg: 'text-sm px-3.5 py-1.5 font-bold',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border tracking-wide uppercase font-medium ${getStyle()} ${sizeClass}`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${getDotColor()}`} />}
      {STATUS_LABELS[status] || status}
    </span>
  );
};
