import React, { useState } from 'react';
import {
  Printer,
  Share2,
  Copy,
  Check,
  X,
  Phone,
  Calendar,
  UserCheck,
  Sparkles,
} from 'lucide-react';
import { StoreSettings, Transaction } from '../types';
import { formatRupiah } from '../utils/currency';
import { formatDateIndo, formatDateTimeIndo } from '../utils/date';
import { StatusBadge } from './StatusBadge';

interface Props {
  transaction: Transaction | null;
  settings: StoreSettings;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptModal: React.FC<Props> = ({
  transaction,
  settings,
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>('58mm');

  if (!isOpen || !transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const getReceiptPlainText = () => {
    const divider = '================================';
    const subDivider = '--------------------------------';
    const lines = [
      divider,
      `          LAUNDRYPOS`,
      `       ${settings.store_name}`,
      `   ${settings.address}`,
      `        Telp: ${settings.phone}`,
      divider,
      `No  : ${transaction.invoice}`,
      `Tgl : ${formatDateIndo(transaction.date)}`,
      `Est : ${formatDateIndo(transaction.estimated_completion_date)}`,
      `Kasir: ${transaction.created_by}`,
      ``,
      `Pelanggan:`,
      `${transaction.customer_name}`,
      `${transaction.customer_phone}`,
      subDivider,
      ...transaction.items.map(
        item =>
          `${item.service_name}\n${item.qty} ${item.unit} x ${formatRupiah(item.price).replace('Rp\u00a0', '')} = ${formatRupiah(item.subtotal).replace('Rp\u00a0', '')}`
      ),
      subDivider,
      `SUBTOTAL       : ${formatRupiah(transaction.subtotal)}`,
      transaction.discount > 0 ? `DISKON         : -${formatRupiah(transaction.discount)}` : null,
      `TOTAL          : ${formatRupiah(transaction.total)}`,
      `BAYAR          : ${formatRupiah(transaction.paid_amount)}`,
      transaction.debt_amount > 0 ? `PIUTANG (SISA) : ${formatRupiah(transaction.debt_amount)}` : null,
      transaction.change_amount > 0 ? `KEMBALIAN      : ${formatRupiah(transaction.change_amount)}` : null,
      subDivider,
      `Status Cucian  : ${transaction.status.toUpperCase()}`,
      `Status Bayar   : ${transaction.payment_status.toUpperCase()}`,
      transaction.rack_location ? `Lokasi Rak     : ${transaction.rack_location}` : null,
      transaction.perfume_choice ? `Aroma Parfum   : ${transaction.perfume_choice}` : null,
      divider,
      settings.receipt_footer || 'Terima kasih atas kunjungan Anda!',
      divider,
    ].filter(Boolean);

    return lines.join('\n');
  };

  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(getReceiptPlainText());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleWhatsApp = () => {
    let phone = transaction.customer_phone.replace(/[^0-9]/g, '');
    if (phone.startsWith('0')) {
      phone = '62' + phone.substring(1);
    }

    const message = encodeURIComponent(
      `*NOTA LAUNDRY - ${settings.store_name}*\n` +
      `Halo Kak *${transaction.customer_name}*,\n` +
      `Berikut rincian transaksi laundry Anda:\n\n` +
      `📋 No. Nota: *${transaction.invoice}*\n` +
      `📅 Tanggal: ${formatDateTimeIndo(transaction.date)}\n` +
      `⏳ Estimasi Selesai: ${formatDateIndo(transaction.estimated_completion_date)}\n\n` +
      `*Layanan:*\n` +
      transaction.items
        .map(i => `• ${i.service_name} (${i.qty} ${i.unit}) = ${formatRupiah(i.subtotal)}`)
        .join('\n') +
      `\n\n` +
      `💰 *Total: ${formatRupiah(transaction.total)}*\n` +
      `💵 Dibayar: ${formatRupiah(transaction.paid_amount)}\n` +
      (transaction.debt_amount > 0
        ? `⚠️ *Sisa Piutang: ${formatRupiah(transaction.debt_amount)}*\n`
        : `✅ *Status: LUNAS*\n`) +
      `📦 Status Pakaian: *${transaction.status.toUpperCase()}*\n` +
      (transaction.rack_location ? `🏷️ Rak: ${transaction.rack_location}\n` : '') +
      `\nTerima kasih telah mempercayakan pakaian Anda di *${settings.store_name}*!`
    );

    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 no-print">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base">Pratinjau Nota Transaksi</h3>
              <p className="text-xs text-slate-400">{transaction.invoice}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Paper switch & fast actions */}
        <div className="px-6 py-3 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Format:</span>
            <button
              onClick={() => setPaperWidth('58mm')}
              className={`px-2.5 py-1 rounded font-medium transition ${
                paperWidth === '58mm'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-300'
              }`}
            >
              58 mm (Struk Mini)
            </button>
            <button
              onClick={() => setPaperWidth('80mm')}
              className={`px-2.5 py-1 rounded font-medium transition ${
                paperWidth === '80mm'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-300'
              }`}
            >
              80 mm (Standar)
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyText}
              className="flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Tersalin' : 'Salin Teks'}
            </button>
          </div>
        </div>

        {/* Paper receipt view body */}
        <div className="p-6 bg-slate-200/60 max-h-[60vh] overflow-y-auto flex justify-center">
          <div
            className={`bg-white p-5 shadow-lg border border-slate-200 font-mono text-[13px] text-slate-800 transition-all ${
              paperWidth === '58mm' ? 'w-[320px]' : 'w-[400px]'
            }`}
          >
            {/* Store branding */}
            <div className="text-center mb-3">
              <h2 className="text-lg font-black tracking-tight text-slate-900 uppercase">
                {settings.store_name}
              </h2>
              <p className="text-[11px] text-slate-600 leading-tight">{settings.tagline}</p>
              <p className="text-[11px] text-slate-500 mt-1">{settings.address}</p>
              <p className="text-[11px] text-slate-500">WA/Telp: {settings.phone}</p>
            </div>

            <div className="border-t border-dashed border-slate-400 my-2" />

            {/* Metadata */}
            <div className="space-y-1 text-xs text-slate-700">
              <div className="flex justify-between">
                <span>No. Nota:</span>
                <span className="font-bold">{transaction.invoice}</span>
              </div>
              <div className="flex justify-between">
                <span>Tanggal:</span>
                <span>{formatDateTimeIndo(transaction.date)}</span>
              </div>
              <div className="flex justify-between">
                <span>Selesai:</span>
                <span className="font-semibold text-slate-900">
                  {formatDateIndo(transaction.estimated_completion_date)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Kasir:</span>
                <span>{transaction.created_by}</span>
              </div>
            </div>

            <div className="border-t border-dashed border-slate-300 my-2" />

            {/* Customer */}
            <div className="text-xs">
              <span className="text-slate-500">Pelanggan:</span>
              <div className="font-bold text-slate-900">{transaction.customer_name}</div>
              <div className="text-slate-600">{transaction.customer_phone}</div>
            </div>

            <div className="border-t border-dashed border-slate-400 my-2" />

            {/* Items */}
            <div className="space-y-2 text-xs">
              {transaction.items.map((item, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="font-semibold text-slate-900">{item.service_name}</div>
                  <div className="flex justify-between text-slate-600">
                    <span>
                      {item.qty} {item.unit} x {formatRupiah(item.price).replace('Rp\u00a0', '')}
                    </span>
                    <span className="font-mono text-slate-900">
                      {formatRupiah(item.subtotal).replace('Rp\u00a0', '')}
                    </span>
                  </div>
                  {item.notes && <div className="text-[11px] text-slate-500 italic">*{item.notes}</div>}
                </div>
              ))}
            </div>

            <div className="border-t border-dashed border-slate-400 my-2" />

            {/* Financials */}
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span>{formatRupiah(transaction.subtotal)}</span>
              </div>
              {transaction.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Diskon</span>
                  <span>-{formatRupiah(transaction.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-300">
                <span>TOTAL</span>
                <span>{formatRupiah(transaction.total)}</span>
              </div>
              <div className="flex justify-between text-slate-700">
                <span>Bayar ({transaction.payment_methods?.map(p => p.method).join(', ') || 'Cash'})</span>
                <span>{formatRupiah(transaction.paid_amount)}</span>
              </div>
              {transaction.debt_amount > 0 ? (
                <div className="flex justify-between font-bold text-rose-600 bg-rose-50 p-1 rounded">
                  <span>SISA PIUTANG:</span>
                  <span>{formatRupiah(transaction.debt_amount)}</span>
                </div>
              ) : (
                <div className="flex justify-between text-slate-700">
                  <span>Kembali:</span>
                  <span>{formatRupiah(transaction.change_amount || 0)}</span>
                </div>
              )}
            </div>

            <div className="border-t border-dashed border-slate-300 my-2.5" />

            {/* Operasional specs */}
            <div className="text-[11px] space-y-1 text-slate-600">
              <div className="flex justify-between items-center">
                <span>Status Cucian:</span>
                <span className="font-bold text-slate-900 uppercase">{transaction.status}</span>
              </div>
              {transaction.rack_location && (
                <div className="flex justify-between items-center">
                  <span>Lokasi Rak:</span>
                  <span className="font-bold text-slate-900">{transaction.rack_location}</span>
                </div>
              )}
              {transaction.perfume_choice && (
                <div className="flex justify-between items-center">
                  <span>Aroma:</span>
                  <span className="text-slate-800">{transaction.perfume_choice}</span>
                </div>
              )}
            </div>

            <div className="border-t border-dashed border-slate-400 my-3" />

            {/* Footer */}
            <div className="text-center text-[11px] text-slate-500 whitespace-pre-line leading-tight">
              {settings.receipt_footer || 'Terima kasih atas kunjungan Anda!'}
            </div>
            <div className="text-center text-[10px] text-slate-400 mt-2">
              *** LaundryPOS System ***
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
          >
            Tutup (ESC)
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleWhatsApp}
              className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition active:scale-95"
            >
              <Share2 className="w-4 h-4" />
              Kirim WhatsApp
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-5 py-2.5 text-sm font-bold text-white bg-cyan-600 hover:bg-cyan-700 rounded-xl shadow-md transition active:scale-95"
            >
              <Printer className="w-4 h-4" />
              Cetak Nota (F6)
            </button>
          </div>
        </div>
      </div>

      {/* Hidden printable receipt for window.print() */}
      <div className="printable-receipt hidden">
        <div style={{ fontFamily: 'monospace', fontSize: '12px', lineHeight: '1.3' }}>
          <div style={{ textAlign: 'center', marginBottom: '8px' }}>
            <div style={{ fontSize: '15px', fontWeight: 'bold' }}>{settings.store_name}</div>
            <div>{settings.tagline}</div>
            <div>{settings.address}</div>
            <div>Telp: {settings.phone}</div>
          </div>
          <div style={{ borderTop: '1px dashed #000', margin: '6px 0' }} />
          <div>No Nota : {transaction.invoice}</div>
          <div>Tanggal : {formatDateTimeIndo(transaction.date)}</div>
          <div>Selesai : {formatDateIndo(transaction.estimated_completion_date)}</div>
          <div>Kasir   : {transaction.created_by}</div>
          <div style={{ borderTop: '1px dashed #000', margin: '6px 0' }} />
          <div>Pelanggan: {transaction.customer_name} ({transaction.customer_phone})</div>
          <div style={{ borderTop: '1px dashed #000', margin: '6px 0' }} />
          {transaction.items.map((item, i) => (
            <div key={i} style={{ marginBottom: '4px' }}>
              <div>{item.service_name}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{item.qty} {item.unit} x {formatRupiah(item.price).replace('Rp\u00a0', '')}</span>
                <span>{formatRupiah(item.subtotal).replace('Rp\u00a0', '')}</span>
              </div>
            </div>
          ))}
          <div style={{ borderTop: '1px dashed #000', margin: '6px 0' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Subtotal:</span>
            <span>{formatRupiah(transaction.subtotal)}</span>
          </div>
          {transaction.discount > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Diskon:</span>
              <span>-{formatRupiah(transaction.discount)}</span>
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '13px' }}>
            <span>TOTAL:</span>
            <span>{formatRupiah(transaction.total)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Bayar:</span>
            <span>{formatRupiah(transaction.paid_amount)}</span>
          </div>
          {transaction.debt_amount > 0 ? (
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
              <span>SISA PIUTANG:</span>
              <span>{formatRupiah(transaction.debt_amount)}</span>
            </div>
          ) : (
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Kembali:</span>
              <span>{formatRupiah(transaction.change_amount || 0)}</span>
            </div>
          )}
          <div style={{ borderTop: '1px dashed #000', margin: '6px 0' }} />
          <div>Status : {transaction.status.toUpperCase()}</div>
          {transaction.rack_location && <div>Rak    : {transaction.rack_location}</div>}
          <div style={{ borderTop: '1px dashed #000', margin: '6px 0' }} />
          <div style={{ textAlign: 'center', whiteSpace: 'pre-line', fontSize: '10px' }}>
            {settings.receipt_footer}
          </div>
        </div>
      </div>
    </div>
  );
};
