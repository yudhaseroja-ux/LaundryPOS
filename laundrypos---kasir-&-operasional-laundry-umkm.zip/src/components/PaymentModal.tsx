import React, { useState, useEffect } from 'react';
import {
  Banknote,
  QrCode,
  CreditCard,
  Wallet,
  Clock,
  CheckCircle2,
  X,
  Plus,
  Trash2,
  AlertCircle,
} from 'lucide-react';
import { PaymentMethod, SplitPaymentRecord } from '../types';
import { formatRupiah } from '../utils/currency';
import { playBeep } from '../utils/sound';

interface Props {
  isOpen: boolean;
  totalAmount: number;
  customerName: string;
  onClose: () => void;
  onConfirm: (
    paymentMethods: SplitPaymentRecord[],
    paidAmount: number,
    debtAmount: number,
    changeAmount: number,
    paymentStatus: 'lunas' | 'sebagian' | 'belum_lunas'
  ) => void;
}

export const PaymentModal: React.FC<Props> = ({
  isOpen,
  totalAmount,
  customerName,
  onClose,
  onConfirm,
}) => {
  const [isSplit, setIsSplit] = useState(false);
  const [singleMethod, setSingleMethod] = useState<PaymentMethod>('cash');
  const [singleAmount, setSingleAmount] = useState<number>(totalAmount);

  // Split payments
  const [splits, setSplits] = useState<SplitPaymentRecord[]>([
    { method: 'cash', amount: totalAmount },
  ]);

  useEffect(() => {
    if (isOpen) {
      setSingleAmount(totalAmount);
      setSingleMethod('cash');
      setIsSplit(false);
      setSplits([{ method: 'cash', amount: totalAmount }]);
    }
  }, [isOpen, totalAmount]);

  if (!isOpen) return null;

  // Calculations
  const currentTotalPaid = isSplit
    ? splits.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0)
    : singleAmount;

  const debtAmount = Math.max(0, totalAmount - currentTotalPaid);
  const changeAmount = singleMethod === 'cash' && !isSplit ? Math.max(0, currentTotalPaid - totalAmount) : 0;
  
  let paymentStatus: 'lunas' | 'sebagian' | 'belum_lunas' = 'lunas';
  if (currentTotalPaid === 0 || singleMethod === 'piutang') {
    paymentStatus = 'belum_lunas';
  } else if (currentTotalPaid < totalAmount) {
    paymentStatus = 'sebagian';
  }

  const handleQuickCash = (amt: number) => {
    playBeep('beep');
    setSingleAmount(amt);
    setSingleMethod('cash');
  };

  const handleAddSplit = () => {
    const remaining = Math.max(0, totalAmount - currentTotalPaid);
    setSplits([...splits, { method: 'qris', amount: remaining }]);
  };

  const handleRemoveSplit = (idx: number) => {
    if (splits.length <= 1) return;
    setSplits(splits.filter((_, i) => i !== idx));
  };

  const handleUpdateSplit = (idx: number, field: 'method' | 'amount', value: any) => {
    const next = [...splits];
    if (field === 'amount') {
      next[idx].amount = Number(value) || 0;
    } else {
      next[idx].method = value;
    }
    setSplits(next);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playBeep('cash');

    let finalRecords: SplitPaymentRecord[] = [];
    let finalPaid = 0;

    if (isSplit) {
      finalRecords = splits.filter(s => s.amount > 0);
      finalPaid = finalRecords.reduce((acc, curr) => acc + curr.amount, 0);
    } else {
      if (singleMethod === 'piutang') {
        finalRecords = [{ method: 'piutang', amount: 0 }];
        finalPaid = 0;
      } else {
        finalPaid = Math.min(singleAmount, totalAmount);
        finalRecords = [{ method: singleMethod, amount: finalPaid }];
      }
    }

    const calculatedDebt = Math.max(0, totalAmount - finalPaid);
    const calculatedChange = !isSplit && singleMethod === 'cash' ? Math.max(0, singleAmount - totalAmount) : 0;
    
    let status: 'lunas' | 'sebagian' | 'belum_lunas' = 'lunas';
    if (finalPaid === 0) {
      status = 'belum_lunas';
    } else if (finalPaid < totalAmount) {
      status = 'sebagian';
    }

    onConfirm(finalRecords, finalPaid, calculatedDebt, calculatedChange, status);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <span className="text-xs text-cyan-400 font-semibold uppercase tracking-wider">
              Pembayaran Laundry (F5)
            </span>
            <h3 className="font-bold text-lg">{customerName}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bill Total Banner */}
        <div className="px-6 py-4 bg-gradient-to-r from-cyan-600 to-sky-700 text-white flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-cyan-100 font-medium">Total Tagihan</div>
            <div className="text-3xl font-extrabold tracking-tight">{formatRupiah(totalAmount)}</div>
          </div>
          <div className="text-right">
            <button
              type="button"
              onClick={() => setIsSplit(!isSplit)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                isSplit
                  ? 'bg-amber-400 text-amber-950 shadow'
                  : 'bg-white/20 hover:bg-white/30 text-white'
              }`}
            >
              {isSplit ? 'Mode Normal' : 'Split Payment (Gabungan)'}
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {!isSplit ? (
            /* Single payment mode */
            <>
              {/* Payment Methods */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Pilih Metode Pembayaran
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSingleMethod('cash');
                      if (singleAmount === 0) setSingleAmount(totalAmount);
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-xs font-bold ${
                      singleMethod === 'cash'
                        ? 'border-cyan-600 bg-cyan-50/80 text-cyan-700 ring-2 ring-cyan-600/20'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                    }`}
                  >
                    <Banknote className="w-5 h-5" />
                    Cash
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSingleMethod('qris');
                      setSingleAmount(totalAmount);
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-xs font-bold ${
                      singleMethod === 'qris'
                        ? 'border-cyan-600 bg-cyan-50/80 text-cyan-700 ring-2 ring-cyan-600/20'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                    }`}
                  >
                    <QrCode className="w-5 h-5" />
                    QRIS
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSingleMethod('transfer');
                      setSingleAmount(totalAmount);
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-xs font-bold ${
                      singleMethod === 'transfer'
                        ? 'border-cyan-600 bg-cyan-50/80 text-cyan-700 ring-2 ring-cyan-600/20'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                    }`}
                  >
                    <CreditCard className="w-5 h-5" />
                    Transfer
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSingleMethod('ewallet');
                      setSingleAmount(totalAmount);
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-xs font-bold ${
                      singleMethod === 'ewallet'
                        ? 'border-cyan-600 bg-cyan-50/80 text-cyan-700 ring-2 ring-cyan-600/20'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                    }`}
                  >
                    <Wallet className="w-5 h-5" />
                    E-Wallet
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSingleMethod('piutang');
                      setSingleAmount(0);
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-xs font-bold ${
                      singleMethod === 'piutang'
                        ? 'border-rose-600 bg-rose-50 text-rose-700 ring-2 ring-rose-600/20'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                    }`}
                  >
                    <Clock className="w-5 h-5" />
                    Piutang
                  </button>
                </div>
              </div>

              {/* Amount input */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    {singleMethod === 'piutang' ? 'Dibayar Sekarang (DP)' : 'Nominal Diterima'}
                  </label>
                  {singleMethod === 'cash' && (
                    <button
                      type="button"
                      onClick={() => handleQuickCash(totalAmount)}
                      className="text-xs text-cyan-600 font-bold hover:underline"
                    >
                      Uang Pas
                    </button>
                  )}
                </div>

                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">
                    Rp
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={singleAmount || ''}
                    onChange={e => setSingleAmount(Number(e.target.value) || 0)}
                    disabled={singleMethod === 'piutang'}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-xl text-xl font-bold font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    placeholder="0"
                    autoFocus
                  />
                </div>

                {/* Quick cash amounts pills */}
                {singleMethod === 'cash' && (
                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    <button
                      type="button"
                      onClick={() => handleQuickCash(totalAmount)}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700"
                    >
                      Pas: {formatRupiah(totalAmount)}
                    </button>
                    {[10000, 20000, 50000, 100000, 200000].map(amt => {
                      if (amt >= totalAmount) {
                        return (
                          <button
                            key={amt}
                            type="button"
                            onClick={() => handleQuickCash(amt)}
                            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-100 hover:bg-cyan-50 hover:text-cyan-700 hover:border-cyan-300 border border-slate-200 text-slate-700 transition"
                          >
                            {formatRupiah(amt)}
                          </button>
                        );
                      }
                      return null;
                    })}
                  </div>
                )}
              </div>
            </>
          ) : (
            /* Split payment mode */
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Rincian Gabungan Pembayaran
                </label>
                <button
                  type="button"
                  onClick={handleAddSplit}
                  className="flex items-center gap-1 text-xs font-bold text-cyan-600 hover:text-cyan-700"
                >
                  <Plus className="w-3.5 h-3.5" /> Tambah Metode
                </button>
              </div>

              {splits.map((split, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <select
                    value={split.method}
                    onChange={e => handleUpdateSplit(idx, 'method', e.target.value)}
                    className="px-2.5 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  >
                    <option value="cash">Cash (Tunai)</option>
                    <option value="qris">QRIS</option>
                    <option value="transfer">Transfer Bank</option>
                    <option value="ewallet">E-Wallet</option>
                  </select>

                  <div className="relative flex-1">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                      Rp
                    </span>
                    <input
                      type="number"
                      min="0"
                      step="1000"
                      value={split.amount || ''}
                      onChange={e => handleUpdateSplit(idx, 'amount', e.target.value)}
                      className="w-full pl-8 pr-2.5 py-2 bg-white border border-slate-300 rounded-lg text-sm font-bold font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  </div>

                  {splits.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveSplit(idx)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Realtime Status Summary */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Total Tagihan:</span>
              <span className="font-semibold text-slate-900">{formatRupiah(totalAmount)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Total Dibayar:</span>
              <span className="font-semibold text-slate-900">{formatRupiah(currentTotalPaid)}</span>
            </div>

            {changeAmount > 0 && (
              <div className="flex justify-between items-center pt-1 border-t border-slate-200 text-emerald-700 font-bold text-sm">
                <span>Kembalian:</span>
                <span>{formatRupiah(changeAmount)}</span>
              </div>
            )}

            {debtAmount > 0 && (
              <div className="flex justify-between items-center pt-1 border-t border-slate-200 text-rose-600 font-bold text-sm">
                <span className="flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" /> Sisa Piutang:
                </span>
                <span>{formatRupiah(debtAmount)}</span>
              </div>
            )}

            <div className="flex justify-between items-center pt-1 border-t border-slate-200">
              <span>Status Pelunasan:</span>
              <span
                className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                  paymentStatus === 'lunas'
                    ? 'bg-emerald-100 text-emerald-800'
                    : paymentStatus === 'sebagian'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {paymentStatus === 'lunas'
                  ? 'LUNAS'
                  : paymentStatus === 'sebagian'
                  ? 'BAYAR SEBAGIAN (PIUTANG)'
                  : 'BELUM DIBAYAR (PIUTANG TOTAL)'}
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
            >
              Batal (ESC)
            </button>

            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 text-sm font-bold text-white bg-cyan-600 hover:bg-cyan-700 active:scale-95 rounded-xl shadow-md transition"
            >
              <CheckCircle2 className="w-4 h-4" />
              Selesaikan Transaksi
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
