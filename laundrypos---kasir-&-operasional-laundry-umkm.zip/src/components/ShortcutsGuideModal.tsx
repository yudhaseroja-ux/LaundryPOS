import React from 'react';
import { Keyboard, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsGuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'F2', label: 'Transaksi Baru', desc: 'Buka form POS transaksi baru / reset keranjang' },
    { key: 'F3', label: 'Cari Pelanggan', desc: 'Fokuskan input pencarian pelanggan' },
    { key: 'F4', label: 'Pilih Layanan', desc: 'Fokuskan pilihan katalog layanan' },
    { key: 'F5', label: 'Pembayaran', desc: 'Buka modal pembayaran & pilih metode kasir' },
    { key: 'F6', label: 'Cetak Nota', desc: 'Cetak nota struk transaksi terakhir' },
    { key: 'ESC', label: 'Tutup Dialog', desc: 'Tutup modal / pop-up aktif seketika' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Keyboard className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-base">Panduan Shortcut Keyboard POS</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-3">
          <p className="text-xs text-slate-500 mb-2">
            Gunakan tombol keyboard berikut untuk mempercepat input transaksi saat antrian kasir ramai:
          </p>

          <div className="space-y-2">
            {shortcuts.map((sc, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200"
              >
                <div>
                  <div className="font-bold text-sm text-slate-800">{sc.label}</div>
                  <div className="text-xs text-slate-500">{sc.desc}</div>
                </div>
                <kbd className="px-2.5 py-1 text-xs font-mono font-bold bg-white text-slate-800 border border-slate-300 rounded-lg shadow-xs">
                  {sc.key}
                </kbd>
              </div>
            ))}
          </div>
        </div>

        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold text-white bg-slate-800 hover:bg-slate-900 rounded-xl transition"
          >
            Mengerti (ESC)
          </button>
        </div>
      </div>
    </div>
  );
};
