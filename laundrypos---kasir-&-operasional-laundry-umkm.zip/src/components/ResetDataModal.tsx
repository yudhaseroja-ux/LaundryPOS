import React, { useState } from 'react';
import {
  RotateCcw,
  AlertTriangle,
  X,
  CheckCircle2,
  Trash2,
  Sparkles,
  RefreshCw,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface ResetDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onResetDemo: () => void;
  onClearTransactions: () => void;
  onFactoryReset: () => void;
}

export const ResetDataModal: React.FC<ResetDataModalProps> = ({
  isOpen,
  onClose,
  onResetDemo,
  onClearTransactions,
  onFactoryReset,
}) => {
  const [selectedAction, setSelectedAction] = useState<
    'demo' | 'clear_transactions' | 'factory' | null
  >(null);
  const [confirmText, setConfirmText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleExecute = () => {
    setIsProcessing(true);
    setTimeout(() => {
      if (selectedAction === 'demo') {
        onResetDemo();
      } else if (selectedAction === 'clear_transactions') {
        onClearTransactions();
      } else if (selectedAction === 'factory') {
        onFactoryReset();
      }
      setIsProcessing(false);
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-rose-600 to-amber-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/20 backdrop-blur-xs">
              <RotateCcw className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-base tracking-tight">Reset Data LaundryPOS</h3>
              <p className="text-xs text-rose-100">
                Pilih jenis reset data yang ingin Anda terapkan
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/20 text-white/80 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600 leading-relaxed">
            Anda dapat memulihkan sampel data bawaan PRD, mengosongkan riwayat transaksi untuk mulai jualan nyata, atau melakukan reset total setelan pabrik.
          </p>

          <div className="space-y-3">
            {/* Option 1: Reset ke Data Demo PRD */}
            <div
              onClick={() => setSelectedAction('demo')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-start gap-3.5 ${
                selectedAction === 'demo'
                  ? 'border-cyan-600 bg-cyan-50/70'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div
                className={`p-2.5 rounded-xl shrink-0 ${
                  selectedAction === 'demo'
                    ? 'bg-cyan-600 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">
                    Reset ke Data Demo Awal (PRD)
                  </span>
                  {selectedAction === 'demo' && (
                    <CheckCircle2 className="w-4 h-4 text-cyan-600" />
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Mengembalikan data sampel transaksi pelanggan (Budi, Siti, Andi), omzet demo, piutang contoh, dan daftar layanan lengkap.
                </p>
              </div>
            </div>

            {/* Option 2: Kosongkan Transaksi (Mulai Usaha Baru) */}
            <div
              onClick={() => setSelectedAction('clear_transactions')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-start gap-3.5 ${
                selectedAction === 'clear_transactions'
                  ? 'border-amber-500 bg-amber-50/70'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div
                className={`p-2.5 rounded-xl shrink-0 ${
                  selectedAction === 'clear_transactions'
                    ? 'bg-amber-500 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">
                    Kosongkan Semua Transaksi (Fresh Start)
                  </span>
                  {selectedAction === 'clear_transactions' && (
                    <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Mereset total transaksi, antrian cucian, dan piutang menjadi 0. Master tarif layanan dan nama toko tetap dipertahankan.
                </p>
              </div>
            </div>

            {/* Option 3: Reset Total Pabrik */}
            <div
              onClick={() => setSelectedAction('factory')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition flex items-start gap-3.5 ${
                selectedAction === 'factory'
                  ? 'border-rose-600 bg-rose-50/70'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div
                className={`p-2.5 rounded-xl shrink-0 ${
                  selectedAction === 'factory'
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">
                    Reset Total Setelan Pabrik
                  </span>
                  {selectedAction === 'factory' && (
                    <CheckCircle2 className="w-4 h-4 text-rose-600" />
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Hapus seluruh database lokal, keluar dari sesi, dan kembali ke halaman login (admin / admin).
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition"
          >
            Batal
          </button>

          <button
            type="button"
            disabled={!selectedAction || isProcessing}
            onClick={handleExecute}
            className={`px-5 py-2.5 text-xs font-bold rounded-xl shadow-md transition flex items-center gap-2 ${
              !selectedAction || isProcessing
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                : selectedAction === 'factory'
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : selectedAction === 'clear_transactions'
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-cyan-600 hover:bg-cyan-700 text-white'
            }`}
          >
            <RotateCcw className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
            <span>
              {isProcessing
                ? 'Memproses Reset...'
                : selectedAction === 'factory'
                ? 'Terapkan Reset Pabrik'
                : selectedAction === 'clear_transactions'
                ? 'Kosongkan Transaksi Sekarang'
                : selectedAction === 'demo'
                ? 'Pulihkan Data Demo'
                : 'Pilih Opsi di Atas'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
