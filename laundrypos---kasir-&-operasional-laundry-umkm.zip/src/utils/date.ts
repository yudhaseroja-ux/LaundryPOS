/**
 * Utility for formatting Dates & Timestamps in Indonesian locale
 */

export function formatDateIndo(dateStrOrObj: string | Date): string {
  try {
    const d = typeof dateStrOrObj === 'string' ? new Date(dateStrOrObj) : dateStrOrObj;
    if (isNaN(d.getTime())) return '-';
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return '-';
  }
}

export function formatDateTimeIndo(dateStrOrObj: string | Date): string {
  try {
    const d = typeof dateStrOrObj === 'string' ? new Date(dateStrOrObj) : dateStrOrObj;
    if (isNaN(d.getTime())) return '-';
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return '-';
  }
}

export function formatTimeOnly(dateStrOrObj: string | Date): string {
  try {
    const d = typeof dateStrOrObj === 'string' ? new Date(dateStrOrObj) : dateStrOrObj;
    if (isNaN(d.getTime())) return '-';
    return d.toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  } catch {
    return '-';
  }
}

export function getTodayISODate(): string {
  return new Date().toISOString().split('T')[0];
}

export function isToday(dateStr: string): boolean {
  if (!dateStr) return false;
  const today = getTodayISODate();
  return dateStr.startsWith(today);
}

export function isOverdue(estimatedCompletionDate: string, status?: string): boolean {
  if (!estimatedCompletionDate) return false;
  if (status === 'selesai') return false;
  const estTime = new Date(estimatedCompletionDate).getTime();
  if (isNaN(estTime)) return false;
  return estTime < Date.now();
}

export function getOverdueDuration(estimatedCompletionDate: string): string {
  const estTime = new Date(estimatedCompletionDate).getTime();
  if (isNaN(estTime)) return '';
  const diffMs = Date.now() - estTime;
  if (diffMs <= 0) return '';
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  if (diffHours < 1) {
    return '< 1 jam';
  }
  if (diffHours < 24) {
    return `${diffHours} jam`;
  }
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays} hari`;
}
